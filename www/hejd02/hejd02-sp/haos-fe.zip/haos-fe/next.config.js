const nextTranslate = require('next-translate');

module.exports = {
	reactStrictMode: true,
	i18n: {
		locales: ['cs', 'en'],
		defaultLocale: 'cs',
	},
	...nextTranslate(),
	images: {
		domains: ['https://api.haos.store', '127.0.0.1'],
	},
};
