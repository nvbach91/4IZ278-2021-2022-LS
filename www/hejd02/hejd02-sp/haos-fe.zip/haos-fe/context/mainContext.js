import { createContext, useContext, useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { ADDRESS } from '../constants/routes';
import { useRouter } from 'next/router';
import useTranslation from 'next-translate/useTranslation';

//photos
import belt from '/public/images/belt_photo.jpg';
import belt2 from '/public/images/belt.png';
import quality from '/public/images/quality.png';
import beef_leather from '/public/images/beef_leather.png';
import nickel_buckle from '/public/images/nickel_buckle.png';
import originality from '/public/images/originality.png';

import bitcoin2 from '/public/images/b2.jpg';
import bitcoin1 from '/public/images/b1.png';

import ethereum2 from '/public/images/e2.jpg';
import ethereum1 from '/public/images/e1.png';

const MainContext = createContext();
export function MainProvider({ children }) {
	const router = useRouter();
	let { t } = useTranslation();
	const data = [
		{
			id: 1,
			name: `${t('beltComponent:bitcoinTitle')}`,
			unBeltName: `${t('beltComponent:bitcoinSubtitle')}`,
			description: `${t('beltComponent:bitcoin_description1')}`,
			description2: `${t('beltComponent:bitcoin_description2')}`,
			image: bitcoin1,
			image2: bitcoin2,
			link: 'bitcoin_pasek',
			text: `${t('beltComponent:bitcoin_description2')}`,
		},

		{
			id: 2,
			name: `${t('beltComponent:ethereumTitle')}`,
			unBeltName: `${t('beltComponent:ethereumSubtitle')}`,
			description: `${t('beltComponent:ethereum_description1')}`,
			image: ethereum1,
			image2: ethereum2,
			link: 'ethereum_pasek',
			text: `${t('beltComponent:ethereum_description2')}`,
		},
	];

	// products
	const [products, setProducts] = useState([]);
	useEffect(() => {
		axios.get(`${ADDRESS}/product`).then(response => {
			setProducts(response.data.data);
		});
	}, []);

	// window width
	const [windowWidth, setWindowWidth] = useState(0);
	useEffect(() => {
		if (typeof window !== undefined) {
			setWindowWidth(window.innerWidth);
		}
	}, []);
	const handleResize = () => {
		setWindowWidth(window.innerWidth);
	};

	useEffect(() => {
		window.addEventListener('resize', handleResize);
		return () => window.removeEventListener('resize', handleResize);
	});

	// login
	const [logged, setLogged] = useState("");
	useEffect(() => {
		if (typeof window !== "undefined" && localStorage.getItem("userData")){
			setLogged(JSON.parse(localStorage.getItem('userData')).role);
		}

	}, [])

	// size guide
	const [sizeGuideActive, setSizeGuideActive] = useState(false);

	// cart
	const [kosikError, setKosikError] = useState('');
	const [step, setStep] = useState('');
	const [total, setTotal] = useState(0);
	const [newItem, setNewItem] = useState([]);
	const [items, setItems] = useState(0);
	const [cartLoading, setCartLoading] = useState(true);

	useEffect(() => {
		myFunction();
		return () => {
			setProducts([]);
			setItems(0);
		};
	}, []);

	const myFunction = () => {
		axios.get(`${ADDRESS}/product`).then(res => {
			setProducts(res.data.data);
		});
		if (sessionStorage.getItem('products') !== null) {
			setItems(JSON.parse(sessionStorage.getItem('products')).length);
		}
	};

	return (
		<MainContext.Provider
			value={{
				windowWidth,
				data,
				kosikError,
				setKosikError,
				step,
				setStep,
				products,
				items,
				setItems,
				total,
				setTotal,
				newItem,
				setNewItem,
				cartLoading,
				setCartLoading,
				logged,
				setLogged,
				sizeGuideActive,
				setSizeGuideActive
			}}
		>
			{children}
		</MainContext.Provider>
	);
}
export function useMainContext() {
	return useContext(MainContext);
}
