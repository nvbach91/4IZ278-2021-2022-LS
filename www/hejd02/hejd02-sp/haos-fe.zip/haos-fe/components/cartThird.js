import axios from 'axios';
import useTranslation from 'next-translate/useTranslation';
import { ADDRESS } from '../constants/routes';

const CartThird = props => {
	let { t } = useTranslation();
	const data = JSON.parse(sessionStorage.getItem('personal_data'));
	const orderRequest = e => {
		e.preventDefault();
		const formData = new FormData();
		let productsArray = [];
		Object.values(JSON.parse(sessionStorage.getItem('products'))).map(item => {
			productsArray.push(item.product_id);
		});
		console.log(JSON.parse(localStorage.getItem('userData')).id);
		console.log(JSON.parse(sessionStorage.getItem('personal_data')).note);
		const cartObj = {
			user_id: JSON.parse(localStorage.getItem('userData')).id,
			note:
				JSON.parse(sessionStorage.getItem('personal_data')).note &&
				JSON.parse(sessionStorage.getItem('personal_data')).note
					 !== ""? JSON.parse(sessionStorage.getItem('personal_data')).note
					: '-',
			address_id: 1,
			products: productsArray,
		};

		for (let cart_data in cartObj) {
			// @ts-ignore
			formData.append(cart_data, cartObj[cart_data]);
		}
		axios.post(
			`${ADDRESS}/${JSON.parse(localStorage.getItem('userData')).role}/order`,
			cartObj,
			{
				headers: {
					Authorization: 'Bearer ' + localStorage.getItem('token'),
				},
			},
		);
	};
	return (
		<div
			className={
				'mainBox__third lg:my-24 my-12 mx-auto xl:w-4/6 lg:w-5/6 w-6/6 text-center hidden'
			}
			ref={props.thirdBox}
		>
			<div className="bg-white shadow-2xl md:px-10 px-4 py-6 w-full mx-auto">
				<div className="flex flex-col md:flex-row">
					<div className="md:w-5/12 w-full text-left md:mr-12 mr-0 info order-last md:order-first">
						<div className="mb-5 md:m-2 m-0 w-full font-medium md:h-12 h-8 appearance-none py-2 border-b pl-4">
							{data && `${data.first_name} ${data.last_name}`}
						</div>
						<div className="mb-5 md:m-2 m-0 w-full font-medium md:h-12 h-8 appearance-none py-2 border-b pl-4">
							{data && data.email}
						</div>
						<div className="mb-5 md:m-2 m-0 w-full font-medium md:h-12 h-8 appearance-none py-2 border-b pl-4">
							{t('cartThird:phoneNumber')} {data && data.phone}
						</div>
						<div className="mb-5 md:m-2 m-0 w-full font-medium md:h-12 h-8 appearance-none py-2 border-b pl-4">
							{`${data && data.street} ${data && data.house_number}`}
						</div>
						<div className="mb-5 md:m-2 m-0 w-full font-medium md:h-12 h-8 appearance-none py-2 border-b pl-4">
							{`${data && data.town} ${data && data.postal_code}`}
						</div>
						<div className="mb-5 md:m-2 m-0 w-full font-medium md:h-12 note appearance-none py-2 border-b pl-4">
							{`${t('cartSecond:note')}: ${
								data && data.note !== '' ? data.note : ''
							}`}
						</div>
						<div className="mb-5 md:m-2 m-0 w-full font-medium md:h-12 h-8 appearance-none py-2 border-b pl-4">
							{t('cartThird:payment')}
						</div>
						<div className="mb-5 md:m-2 m-0 w-full font-medium md:h-12 h-8 appearance-none py-2 border-b pl-4">
							{t('cartThird:delivery')}: {data && data.delivery}
						</div>
					</div>
					<div className="md:w-7/12 w-full md:mb-0 mb-5 flex flex-col justify-between">
						<div>
							{sessionStorage.getItem('products') &&
							sessionStorage.getItem('products') !== '[]'
								? JSON.parse(sessionStorage.getItem('products')).map(
										(item, index) => {
											const {
												product_id,
												title,
												quantity,
												price,
												color,
												size,
											} = item;
											return (
												<div
													className="shrnuti__item flex text-left items-center justify-between my-6 py-6 px-4 relative"
													id={product_id}
													key={index}
												>
													<div className="w-full">
														<h1 className="font-medium md:mb-2 mb-1">
															{title}
														</h1>
														<h6 className="font-medium">
															{t('cartThird:size')}: {size}
														</h6>
														{/* <h6 className="font-medium">
														{t('cartThird:color')}: {color}
													</h6> */}
														<h6 className="font-medium">
															{t('cartThird:amount')}: {quantity}
														</h6>
													</div>
													<div className="w-full font-medium price-full xl:text-right md:text-left text-right cena xl:mt-0 mt-3">
														{price} Kč
														<span className="price-span">
															/ 1 {t('cartFirst:item')}
														</span>
													</div>
												</div>
											);
										},
								  )
								: null}
						</div>
						<div className="celkovaCena font-bold my-8 text-right">
							{t('cartThird:total')}:{' '}
							{data &&
							(data.delivery.includes('Česká pošta') ||
								data.delivery.includes('Czech Post'))
								? props.total + 99
								: props.total + 89}{' '}
							Kč
						</div>
					</div>
				</div>
			</div>
			<div className="mx-auto text-right mt-10 w-full flex justify-between">
				<button
					className="font-medium text-white bg-gray-600 w-32 py-1"
					onClick={() => {
						props.setStep('thirdToSecond');
						sessionStorage.setItem('step', '2');
					}}
				>
					{t('cartThird:backBtn')}
				</button>
				<button
					className="font-medium text-white bg-gray-600 w-32 py-1"
					onClick={e => {
						if (
							localStorage.getItem('userData') &&
							JSON.parse(localStorage.getItem('userData')).id &&
							JSON.parse(localStorage.getItem('userData')).role
						) {
							props.setStep('thirdToFourth');
							sessionStorage.setItem('step', '4');
							orderRequest(e);
						} else {
							props.setLoggedErrState([true, 'user']);
							sessionStorage.setItem('logging', true);
						}
					}}
				>
					{t('cartThird:orderBtn')}
				</button>
			</div>
		</div>
	);
};

export default CartThird;
