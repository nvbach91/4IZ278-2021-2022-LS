import {useEffect, useState} from "react";
import {useRouter} from "next/router";
import {ADDRESS, ADDRESS_SEO} from "../constants/routes";
import Head from "next/head";
import axios from "axios";

// icon
import icon from "../public/favicon.ico";

// components
import Navbar from "./navbar";
import Footer from './footer';
import CookieLista from './cookieLista';
import SizeGuide from "./sizeGuide";

import { useMainContext } from '../context/mainContext.js';

const Layout = ({ children, ...pageProps }) => {
	const [user, setUser] = useState({});
	const [loading, setLoading] = useState(true);
	const { products } = useMainContext();
	const { cartLoading } = useMainContext();
	const { setCartLoading } = useMainContext();
	const { setSizeGuideActive } = useMainContext();
	const { sizeGuideActive } = useMainContext();
	const router = useRouter();
	const robots =
		pageProps.robots === true ? 'index, follow' : 'noindex, nofollow';

	// useEffect(()=>{
	// 	let user = window.sessionStorage.getItem("user")? JSON.parse(window.sessionStorage.getItem("user")): {}
	// 	user = router.pathname.includes("odhlaseni") ? {}:user
	// 	setUser(user)
	// 	const restrict = 'admin'
	// 	if(router.pathname.includes(restrict) &&!router.pathname.includes("odhlaseni")){
	// 		if(window.sessionStorage.getItem("token") && !window.sessionStorage.getItem("user")) {
	// 			let tok = window.sessionStorage.getItem('token').slice(1, -1)
	// 			console.log(tok)
	// 			axios.get(`${ADDRESS}/user`, {headers: {'Authorization': 'Bearer ' + tok}})
	// 				.then(res => {
	// 					window.sessionStorage.setItem('user', JSON.stringify(res.data))
	// 					setUser(res.data)
	// 				})
	// 				.catch(err => router.push("/404"))
	// 		}else if (!window.sessionStorage.getItem("user")){
	// 			router.push("/404")
	// 			setUser({})
	// 		}
	// 	}
	// 	setLoading(false)
	// },[])

	useEffect(() => {
		if (products && cartLoading) {
			setLoading(false);
		}
	}, [products, cartLoading]);

	useEffect(() => {
		if (router.pathname !== 'kosik') {
			setCartLoading(true);
		}
	}, [cartLoading]);

	return (
		<div style={{ overflowX: 'hidden' }}>
			<Head>
				<link rel="icon" href={icon.src} />
				<link rel="apple-touch-icon" href={icon.src} />
				<link rel="manifest" href="../public/manifest.json" />

				<script
					async
					src="https://www.googletagmanager.com/gtag/js?id=G-FKYTBKDJK2"
				/>

				<script
					dangerouslySetInnerHTML={{
						__html: `
                                window.dataLayer = window.dataLayer || [];
                                function gtag(){dataLayer.push(arguments);}
                                gtag('js', new Date());
                                gtag('config', 'G-FKYTBKDJK2', { page_path: window.location.pathname });
                            `,
					}}
				/>

				<title>{'HaoS.store | ' + pageProps.title}</title>
				<meta name="theme-color" content="#144474" />
				<meta name={'description'} content="Haos.store.cz - " />
				<meta name={'robots'} content={robots} />
				<meta property="og:type" content={pageProps.pageType} />
				<meta property="og:title" content={'HaoS.store | ' + pageProps.title} />
				<meta property="og:description" content="Haos.store.cz - " />
				{/*<meta*/}
				{/*	property="og:image"*/}
				{/*	content="http://hejnadaniel.cz/logoVyresme.png"*/}
				{/*/>*/}
				<meta property="og:url" content={ADDRESS_SEO} />
				<meta property="og:site_name" content="Haos.store.cz" />
				<link rel="canonical" href={ADDRESS_SEO + router.pathname} />
			</Head>
			{!loading && (
				<div className="flex flex-col justify-between min-h-screen">
					<SizeGuide
						sizeGuideActive={sizeGuideActive}
						setSizeGuideActive={setSizeGuideActive}
					/>
					<Navbar user={user} />
					{children}
					<CookieLista />
					<Footer user={user} />
				</div>
			)}
		</div>
	);
};

export default Layout;
