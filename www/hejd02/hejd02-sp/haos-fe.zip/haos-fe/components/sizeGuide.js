import React, { useRef, useEffect } from 'react';
import gsap from 'gsap';
import useTranslation from 'next-translate/useTranslation';

const SizeGuide = ({ sizeGuideActive, setSizeGuideActive }) => {
	const sizeGuideRef = useRef();
	const sizeGuideRef2 = useRef();
	let tl = gsap.timeline();
	let { t } = useTranslation();

	const hideTheSizeGuide = () => {
		if (sizeGuideRef.current && sizeGuideRef2.current) {
			tl.to(sizeGuideRef2.current, {
				opacity: 0,
			});
			tl.to(sizeGuideRef2.current, {
				display: 'none',
			});
			tl.to(
				sizeGuideRef.current,
				{
					opacity: 0,
					onComplete: function () {
						setSizeGuideActive(false),
							gsap.to(sizeGuideRef.current, {
								display: 'none',
							});
					},
				},
				'<',
			);
		}
	};

	const displayTheSizeGuide = () => {
		if (sizeGuideRef.current && sizeGuideRef2.current) {
			tl.set(sizeGuideRef.current, {
				display: 'block',
			});
			tl.to(sizeGuideRef.current, {
				opacity: .75,
			});
			tl.to(sizeGuideRef2.current, {
				display: 'block',
			}, "<");
			tl.to(sizeGuideRef2.current, {
				opacity: 1,
			});
		}
	};

	useEffect(() => {
		if (sizeGuideActive) {
			displayTheSizeGuide();
		}
	}, [sizeGuideActive]);
	return (
		<div>
			<div className="sizeGuide hidden opacity-0" ref={sizeGuideRef} />
			<div
				className="sizeGuide-container md:p-8 p-6 hidden opacity-0"
				ref={sizeGuideRef2}
			>
				<div className="flex title">
					<div
						className="spans-button absolute top-3 right-3 flex justify-center items-center flex-col"
						onClick={() => {
							hideTheSizeGuide();
						}}
					>
						<span className="block h-1 w-6" />
						<span className="block h-1 w-6" />
					</div>
					<h1 className="my-5 w-full text-center">{t('sizeGuide:title')}</h1>
				</div>
				<table>
					<thead>
						<tr>
							<td />
							<td>{t('sizeGuide:waist')}</td>
							<td>{t('sizeGuide:hips')}</td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>XS</td>
							<td>63-65</td>
							<td>88-91</td>
						</tr>
						<tr>
							<td>S</td>
							<td>66-69</td>
							<td>92-95</td>
						</tr>
						<tr>
							<td>M</td>
							<td>70-73</td>
							<td>96-98</td>
						</tr>
						<tr>
							<td>L</td>
							<td>74-77</td>
							<td>99-102</td>
						</tr>
						<tr>
							<td>XL</td>
							<td>78-81</td>
							<td>103-106</td>
						</tr>
						<tr>
							<td>XXL</td>
							<td>82-86</td>
							<td>107-110</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	);
};

export default SizeGuide;
