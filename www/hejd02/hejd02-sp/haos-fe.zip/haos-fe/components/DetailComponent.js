import React, { useEffect, useState } from 'react';
import useTranslation from 'next-translate/useTranslation';

// react light box
import { SRLWrapper } from 'simple-react-lightbox';

// images
import cart from '/public/images/cart.png';
import quality from '/public/images/quality.png';
import beef_leather from '/public/images/beef_leather.png';
import nickel_buckle from '/public/images/nickel_buckle.png';
import originality from '/public/images/originality.png';
import belt from '/public/images/belt_photo.jpg';
import belt2 from '/public/images/belt.png';

import axios from 'axios';
import { ADDRESS } from '/constants/routes';

const DetailComponent = ({
	name,
	unBeltName,
	description,
	price,
	cartHandler,
	setOrderedSize,
	orderedSize,
	quantity,
	setQuantity,
	sizes,
	cartHandlerErr,
	setSizeGuideActive,
	color,
	setColor,
	colorErr,
	setColorErr,
}) => {
	let { t } = useTranslation();
	const options = {
		settings: {
			autoplaySpeed: 1500,
			transitionSpeed: 1200,
			disableKeyboardControls: true,
			disableWheelControls: true,
			disablePanzoom: true,
		},
		caption: {
			captionFontFamily: "'Poppins', sans-serif",
			captionFontWeight: '300',
		},
		progressBar: {
			height: 0,
			showProgressBar: false,
		},
		thumbnails: {
			showThumbnails: true,
		},
	};

	useEffect(() => {
		if (orderedSize === '' && sizes) {
			setOrderedSize(sizes[0].size_type);
		}
	}, []);

	const icons = [
		{
			id: 1,
			text: `${t('detailComponent:quality')}`,
			img: quality.src,
		},
		{
			id: 2,
			text: `${t('detailComponent:beefLeather')}`,
			img: beef_leather.src,
		},
		{
			id: 3,
			text: `${t('detailComponent:nickelBuckle')}`,
			img: nickel_buckle.src,
		},
		{
			id: 4,
			text: `${t('detailComponent:originality')}`,
			img: originality.src,
		},
	];

	const images = [
		{
			id: 1,
			alt: 'belt',
			img: belt.src,
		},
		{
			id: 2,
			alt: 'belt',
			img: belt2.src,
		},
		{
			id: 3,
			alt: 'belt',
			img: belt2.src,
		},
		{
			id: 4,
			alt: 'belt',
			img: belt.src,
		},
		{
			id: 5,
			alt: 'belt',
			img: belt.src,
		},
		{
			id: 6,
			alt: 'belt',
			img: belt2.src,
		},
	];

	return (
		<div className="mainContainer text-center">
			<div className="detail-wrapper flex flex-row md:gap-8 sm:gap-8 gap-4">
				<div className="w-full container-text-wrapper">
					<div className="container-text top-0">
						<div className="detail-wrapper-text">
							<h1 className="font-semibold">{name}</h1>
							<h3 className="font-light tracking-wide">{unBeltName}</h3>
							<p
								dangerouslySetInnerHTML={{
									__html: description,
								}}
							/>

						</div>
						<div className="detail-wrapper-icons grid 2xl:grid-cols-4 grid-cols-2 mx-auto justify-between md:gap-0 gap-12">
							{icons &&
								icons.map(item => {
									const { id, text, img } = item;
									return (
										<div key={id} className="flex flex-col">
											<div className="flex flex-col justify-center items-center mx-2">
												<span className="md:mb-3 mb-1.5">{text}</span>
												<img
													alt={text}
													src={img}
													className="sm:h-24 h-20 mx-auto"
												/>
											</div>
										</div>
									);
								})}
						</div>
						<div className="detail-wrapper-info mt-12">
							<div className="font-medium flex flex-col gap-2">
								<h5>{unBeltName}</h5>
								<h5>{price} Kč</h5>
							</div>
							<div className="flex md:flex-row flex-col md:gap-16 gap-3 mt-2 justify-center">
								<div className="flex flex-col md:gap-3 gap-1.5">
									<span>{t('detailComponent:sizeSelect')}</span>
									<select
										name="size"
										id="size"
										onChange={e => {
											setOrderedSize(e.target.value);
										}}
									>
										{sizes.map(item => {
											const { size_id, size_type } = item;
											return (
												<option value={size_type} key={size_id}>
													{size_type}
												</option>
											);
										})}
									</select>
									<span
										className="span-small-text"
										onClick={() => {
											setSizeGuideActive(true);
										}}
									>
										{t('detailComponent:sizeGuide')}
									</span>
								</div>
								{/* <div className="w-full">
									<div className="flex flex-col md:gap-3 gap-1.5">
										<span>{t('detailComponent:colorSelect')}</span>
										<select
											name="size"
											id="colors"
											onChange={e => {
												setColor(e.target.value);
											}}
										>
											<option value={t('detailComponent:black')}>
												{t('detailComponent:black')}
											</option>
											<option value={t('detailComponent:brown')}>
												{t('detailComponent:brown')}
											</option>
										</select>
									</div>
								</div> */}
								<div className="flex flex-col md:gap-3 gap-1.5">
									<span>{t('detailComponent:amount')}</span>
									<span className="number-wrapper">
										<input
											type="number"
											min={1}
											onChange={e => {
												setQuantity(e.target.value);
											}}
											value={quantity}
										/>
									</span>
								</div>
							</div>
							<div className="mt-12">
								<button
									className="flex gap-4 mx-auto items-center"
									onClick={() => {
										cartHandler();
									}}
								>
									<img src={cart.src} alt="cart" />
									<span>{t('detailComponent:button')}</span>
								</button>
							</div>
							<div className="cartErr md:mt-9 mt-6">{cartHandlerErr}</div>
						</div>
					</div>
				</div>
				<div>
					<SRLWrapper
						options={options}
						className="wrapper image-container h-auto"
					>
						<div className="images grid md:grid-cols-2 grid-cols-1 lg:gap-5 md:gap-3 gap-2">
							{images &&
								images.map(item => {
									const { id, img } = item;
									return (
										<div
											className={'w-full h-full item cursor-pointer'}
											key={id}
										>
											<div className="w-full h-full image-container">
												<img alt={''} src={img} />
											</div>
										</div>
									);
								})}
						</div>
					</SRLWrapper>
				</div>
			</div>
		</div>
	);
};

export default DetailComponent;
