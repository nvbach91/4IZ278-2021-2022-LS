import React, { useEffect } from 'react';
import useTranslation from 'next-translate/useTranslation';
import image from '/public/images/logOut-icon.png';
import { useMainContext } from '/context/mainContext.js';
import Link from 'next/link';
import * as ROUTES from '../constants/routes';

const CartNewItem = ({hideTheBox, container}) => {
	let { t } = useTranslation();
	const { newItem } = useMainContext();
	const { setNewItem } = useMainContext();

	useEffect(() => {
		setTimeout(() => {
			hideTheBox();
			setNewItem([]);
		}, 3000);
	}, []);

	return (
		<div
			className="bg-white fixed bottom-5 right-5 cartNewItem"
			ref={container}
		>
			<div
				className="button flex flex-col justify-center items-end w-full absolute top-3 right-3"
				onClick={() => {
					hideTheBox();
				}}
			>
				<span />
				<span />
			</div>
			<div className="md:py-10 md:px-6 py-8 px-4 flex flex-col justify-center items-center">
				<img src={image.src} alt="tick" className="w-12 mb-2" />
				<h2>{t('cartNewItem:item')}</h2>
				{/* <h1 className="md:my-1.5 my-1">
					{newItem.title
						? newItem.title
						: JSON.parse(sessionStorage.getItem('newProducts')) &&
						  JSON.parse(sessionStorage.getItem('newProducts')).title
						? JSON.parse(sessionStorage.getItem('newProducts')).title
						: ''}
				</h1> */}
				<Link href={ROUTES.CART}>
					<a>{t('cartNewItem:itemButton')}</a>
				</Link>
			</div>
		</div>
	);
};

export default CartNewItem;
