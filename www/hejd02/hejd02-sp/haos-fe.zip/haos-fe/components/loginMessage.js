import React, { useEffect, useRef } from 'react';
import useTranslation from 'next-translate/useTranslation';
import image from '/public/images/logOut-icon.png';
import gsap from 'gsap';

const LoginMessage = () => {
	let { t } = useTranslation();
	const container = useRef();
	let tl = gsap.timeline();

	const hideTheBox = () => {
		tl.to(container.current, {
			opacity: 0,
		});
		tl.to(container.current, {
			display: 'none',
			onComplete: function () {
				sessionStorage.removeItem('loggedAnim');
			},
		});
	};

	useEffect(() => {
		setTimeout(() => {
			hideTheBox();
			sessionStorage.removeItem('loggedAnim');
		}, 3000);
	}, [])
	return (
		<div
			className="bg-white fixed bottom-5 right-5 loginMessage"
			ref={container}
		>
			<div
				className="button flex flex-col justify-center items-end w-full absolute top-3 right-3"
				onClick={() => {
					hideTheBox();
				}}
			>
				<span />
				<span />
			</div>
			<div className="md:py-10 md:px-6 py-8 px-4 flex flex-col justify-center items-center">
				<img src={image.src} alt="tick" className="w-12 mb-2" />
				{/* <h2>{t('cartNewItem:item')}</h2> */}
				<h1 className="md:my-1.5 my-1">{t('loginMessage:message')}</h1>
			</div>
		</div>
	);
};

export default LoginMessage;
