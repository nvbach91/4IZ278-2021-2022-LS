import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import Cookies from 'universal-cookie';
import useTranslation from 'next-translate/useTranslation';

const CookieLista = () => {
	const cookies = new Cookies();
	const cookieBanner = useRef();
	let { t } = useTranslation();
	const cookieBannerHandler = param => {
		if (cookieBanner.current) {
			gsap.to(cookieBanner.current, {
				opacity: 0,
				onComplete: function () {
					gsap.to(cookieBanner.current, {
						display: 'none',
					});
				},
			});
		}
		if (param) {
			window['ga-disable-GA_G-FKYTBKDJK2'] = false;
		} else {
			window['ga-disable-GA_G-FKYTBKDJK2'] = true;
		}
	};
	useEffect(() => {
		if (cookieBanner.current && !cookies.get('cookies')) {
			gsap.to(cookieBanner.current, {
				display: 'flex',
				delay: 1.5,
				onComplete: function () {
					gsap.to(cookieBanner.current, {
						opacity: 0.85,
					});
				},
			});
		}
	}, []);
	return (
		<div
			className="fixed bottom-0 left-0 w-screen cookieLista p-6 flex lg:flex-row flex-col items-center justify-between gap-3"
			ref={cookieBanner}
		>
			<div className="cookieLista__text w-full text-center">
				<p>{t('cookieBar:text')}</p>
			</div>
			<div className="cookieLista__btn flex gap-5 justify-end px-16">
				<button
					className="px-5 py-2 rounded-xl"
					onClick={() => {
						cookieBannerHandler(true);
						cookies.set('cookies', true, {
							expires: new Date(Date.now() + 864000000),
						});
					}}
				>
					{t('cookieBar:btn1')}
				</button>
				<button
					className="px-5 py-2 rounded-xl"
					onClick={() => {
						cookieBannerHandler(false);
						cookies.set('cookies', false, {
							expires: new Date(Date.now() + 864000000),
						});
					}}
				>
					{t('cookieBar:btn2')}
				</button>
			</div>
		</div>
	);
};

export default CookieLista;
