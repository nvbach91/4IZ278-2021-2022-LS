import React from 'react';
import useTranslation from 'next-translate/useTranslation';
import { useRouter } from 'next/router';

// links
import Link from 'next/link';
import * as ROUTES from '../constants/routes';

// flags
import UK from '/public/images/UKflag.png';
import CZ from '/public/images/CZflag.png';

const Footer = ({ user }) => {
	let { t } = useTranslation();
	const router = useRouter();
	const links = [
		{ id: 1, name: 'GDPR', link: `${ROUTES.GDPR}` },
		{ id: 2, name: 'Cookies', link: `${ROUTES.COOKIES}` },
		{
			id: 3,
			name: `${t('footer:termsAndConditions')}`,
			link: `${ROUTES.TERMS_AND_CONDITIONS}`,
		},
		{ id: 4, name: `${t('footer:yeetzone')}`, link: 'https://yeetzone.com/' },
		{ id: 5, name: 'Copyright © 2022', link: null },
		{ id: 6, name: 'Haos', link: null },
	];
	return (
		<div className="footer w-screen bg-black flex items-center text-white py-5 text-center px-0">
			<div className="footer-container flex items-center text-center w-full">
				<ul className="flex flex-row items-center sm:gap-x-6 gap-x-3 justify-center mx-auto flex-wrap">
					{links.map(item => {
						const { id, name, link } = item;
						// if (id === 6 && user.id) return null;
						return (
							<li key={id} className="text-white">
								{link !== null && !link.includes('https') ? (
									<>
										<Link href={link}>
											<a>{name}</a>
										</Link>
										<div className="line" />
									</>
								) : link !== null && link.includes('https') ? (
									id === 4 ? (
										<>
											<a href={link} target="_blank" rel="noreferrer">
												{name.split(' ')[0] + ' ' + name.split(' ')[1]}
												<span className="font-semibold">
													{' '}
													{name.split(' ')[2]}
												</span>
											</a>
											<div className="line" />
										</>
									) : (
										<>
											<a href={link} target="_blank" rel="noreferrer">
												{name}
											</a>
											<div className="line" />
										</>
									)
								) : (
									<a>{name}</a>
								)}
							</li>
						);
					})}
					<li className='cursor-pointer' onClick={()=>{router.locale === 'cs'
						? router.push(router.asPath, router.asPath, { locale: 'en' })
						: router.push(router.asPath, router.asPath, { locale: 'cs' });}}>
						<img
							src={router.locale === 'en' ? CZ.src : UK.src}
							alt="flag"
							className="w-6"
						/>
					</li>
				</ul>
			</div>
		</div>
	);
};

export default Footer;
