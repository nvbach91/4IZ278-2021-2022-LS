import React, { useEffect, useRef } from 'react';
import useTranslation from 'next-translate/useTranslation';
import image from '/public/images/login.svg';
import gsap from 'gsap';import Link from 'next/link';
import * as ROUTES from '../constants/routes';

const CartErr = ({ err }) => {
	let { t } = useTranslation();
	let { setLogged } = useTranslation();
	const container = useRef();
	let tl = gsap.timeline();

	const hideTheBox = () => {
		tl.to(container.current, {
			opacity: 0,
		});
		tl.to(container.current, {
			display: 'none',
			onComplete: function () {
				sessionStorage.removeItem('loggedAnim');
			},
		});
	};

	const btnFunction = () => {
		if (typeof window !== 'undefined' && localStorage.getItem('logged')) {
			localStorage.removeItem('logged');
		}
		if (typeof window !== 'undefined' && localStorage.getItem('token')) {
			localStorage.removeItem('token');
		}
		if (typeof window !== 'undefined' && localStorage.getItem('userData')) {
			localStorage.removeItem('userData');
		}
		setLogged("");
	};

	return (
		<div className="bg-white fixed bottom-5 right-5 cartErr2" ref={container}>
			<div
				className="button flex flex-col justify-center items-end w-full absolute top-3 right-3"
				onClick={() => {
					hideTheBox();
				}}
			>
				<span />
				<span />
			</div>
			<div className="md:py-10 md:px-6 py-8 px-4 flex flex-col justify-center items-center">
				<img src={image.src} alt="tick" className="w-12 mb-2" />
				{/* <h2>{t('cartNewItem:item')}</h2> */}
				{err === 'user' ? (
					<h1 className="md:my-1.5 my-1">{t('cartErr:title')}</h1>
				) : (
					<h1 className="md:my-1.5 my-1">{t('cartErr:title2')}</h1>
				)}
				<Link href={ROUTES.LOGIN}>
					<a
						onClick={() => {
							err === 'admin' ? btnFunction() : null;
						}}
					>
						{t('cartErr:btn')}
					</a>
				</Link>
			</div>
		</div>
	);
};

export default CartErr;
