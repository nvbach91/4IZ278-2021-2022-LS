import React, { useState } from 'react';
import Link from 'next/link';
import photo from '/public/images/belt.png';
import useTranslation from 'next-translate/useTranslation';

import belt from '/public/images/belt_photo.jpg';
import belt2 from '/public/images/belt.png';

export default function About({
	id,
	name,
	unBeltName,
	description,
	image,
	image2,
	altTag,
	text,
	link,
}) {
	let { t } = useTranslation();
	const [beltImage, setBeltImage] = useState(image.src);
	const mouseEnterFunction = () => {
		setBeltImage(image2.src);
	};
	const mouseLeaveFunction = () => {
		setBeltImage(image.src);
	};
	return (
		<Link href={`/produkty/${link}`} className="cursor-pointer">
			<a>
				<div
					key={id}
					className="px-3 md:pt-8 pt-6 md:pb-10 pb-8 component-container"
				>
					<div className="main_1 flex justify-center">
						<div className="main_1 flex justify-center flex-col">
							<div className="main_title text-5xl">
								<h1 className="justify-center text-center">{name}</h1>
							</div>
							<div className="second_title text-2xl mt-1">
								<p className="font-light tracking-wide">{unBeltName}</p>
							</div>
							<div className="justify-center text-center leading-8 tracking-wide mb-3.5 mt-3.5">
								<p>{description}</p>
							</div>
							<div
								className="image"
								onMouseEnter={() => {
									mouseEnterFunction();
								}}
								onMouseLeave={() => {
									mouseLeaveFunction();
								}}
							>
								<img src={beltImage} alt={name} />
							</div>
							<div className="justify-center text-center leading-8 tracking-wide mb-3.5 mt-6">
								<p
									dangerouslySetInnerHTML={{
										__html:text,
									}}
								/>
							</div>
							<div>
								<button className="find-button rounded">
									{t('beltComponent:btn')}
								</button>
							</div>
						</div>
					</div>
				</div>
			</a>
		</Link>
	);
}
