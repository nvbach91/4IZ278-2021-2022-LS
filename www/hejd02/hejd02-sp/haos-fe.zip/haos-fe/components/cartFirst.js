import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import img from '/public/images/cart2.png';
import useTranslation from 'next-translate/useTranslation';

const CartFirst = props => {
	const [products, setProducts] = useState([]);
	const [removed, setRemoved] = useState([]);
	const [quantity, setQuantity] = useState(false);
	let { t } = useTranslation();

	useEffect(() => {
		setProducts(JSON.parse(sessionStorage.getItem('products')));
		let x = 0;

		if (sessionStorage.getItem('products') !== null) {
			for (
				let i = 0;
				i < JSON.parse(sessionStorage.getItem('products')).length;
				i++
			) {
				x =
					x +
					parseInt(JSON.parse(sessionStorage.getItem('products'))[i].price) *
						JSON.parse(sessionStorage.getItem('products'))[i].quantity;
			}
		}
		props.setTotal(x);
	}, [removed, quantity]);

	const handleQuantity = (type, value, itemID, itemTitle) => {
		setQuantity(!quantity);
		for (let i = 0; i < products.length; i++) {
			if (products[i].product_id === itemID) {
				if (type === '+') {
					products[i].quantity = products[i].quantity + 1;
				} else {
					products[i].quantity = products[i].quantity - 1;

					if (products[i].quantity <= 0) {
						deleteFromCart(itemTitle);
					}
				}
			}
		}
		sessionStorage.setItem('products', JSON.stringify(products));
		setProducts(JSON.parse(sessionStorage.getItem('products')));
	};

	const deleteFromCart = item => {
		for (let i = 0; i < products.length; i++) {
			if (products[i].title === item.title) {
				var remove = products.splice(i, 1);
				sessionStorage.setItem('products', JSON.stringify(products));
				setRemoved(remove);
				props.setItems(products.length);
				if (products.length === 0) {
					sessionStorage.removeItem("step");
				}
			}
		}
		props.setKosikError('');
	};

	return (
		<div
			className="mainBox__first my-18 mx-auto xl:w-4/6 lg:w-5/6 w-6/6 hidden"
			ref={props.firstBox}
		>
			<p className="error h-8 w-full text-center lg:mt-16 mt-12 lg:mb-12 mb-6 text-red-600">
				{props.kosikError}
			</p>
			<div
				className={
					sessionStorage.getItem('products') &&
					sessionStorage.getItem('products') !== '[]'
						? 'bg-white shadow-2xl md:px-10 px-4 py-6 w-full mx-auto'
						: 'hidden'
				}
			>
				{sessionStorage.getItem('products') &&
				sessionStorage.getItem('products') !== '[]'
					? JSON.parse(sessionStorage.getItem('products')).map((item, index) => {
							const { product_id, title, quantity, price, color, size } = item;
							return (
								<div
									className="relative item flex justify-between border-b border-gray-400 py-6 flex-row items-center"
									id={product_id}
									key={index}
								>
									<div className="flex w-full items-center items-grid">
										<div className="whitespace-pre-line w-full">
											<h1 className="font-medium">{title}</h1>
											{/* <h6 className="font-medium">
												{t('cartFirst:color')}: {color}
											</h6> */}
											<h6 className="font-medium">
												{t('cartFirst:size')}: {size}
											</h6>
										</div>
										<div className="md:flex w-full md:mr-0 mr-5">
											<div className="flex flex-row w-full justify-center items-center">
												<label className={'quantity flex items-center'}>
													<b
														className={'quantityAction'}
														onClick={() =>
															handleQuantity('+', 1, product_id, {
																title: title,
															})
														}
													>
														+
													</b>
													<span className="mx-3">{quantity}</span>
													<b
														className={'quantityAction'}
														onClick={() =>
															handleQuantity('-', 1, product_id, {
																title: title,
															})
														}
													>
														-
													</b>
												</label>
											</div>
											<div className="font-medium price flex items-center justify-center gap-1 w-full md:mt-0 mt-2">
												<span>{price} Kč</span>{' '}
												<span className="price-span">
													/ 1 {t('cartFirst:item')}
												</span>
											</div>
										</div>
									</div>
									<div
										onClick={() => {
											deleteFromCart(item);
										}}
										id={product_id}
										className="absolute md:top-0 -top-0.5 md:right-0 -right-0.5 text-center cursor-pointer md:w-10 w-8 h-8 flex flex-col items-center md:relative span"
									>
										<span
											id={product_id}
											className="md:w-10 w-6 h-0.5 block bg-gray-600 transform rotate-45 relative"
										></span>
										<span
											id={product_id}
											className="md:w-10 w-6 h-0.5 block bg-gray-600 transform -rotate-45 relative"
										></span>
									</div>
								</div>
							);
					  })
					: null}
			</div>
			{sessionStorage.getItem('products') &&
			sessionStorage.getItem('products') !== '[]' ? (
				''
			) : (
				<div className="text-center prazdnyKosik px-3 lg:py-16 py-6 bg-white shadow-2xl">
					<img src={img.src} alt="cart" className="lg:h-40 h-32 mx-auto" />
					<h1 className="my-8">{t('cartFirst:empty')}</h1>
					<Link href="/">
						<a>
							<button className="bg-gray-800 text-white p-3 rounded-lg ">
								{t('cartFirst:emptyButton')}
							</button>
						</a>
					</Link>
				</div>
			)}
			{sessionStorage.getItem('products') &&
			sessionStorage.getItem('products') !== '[]' ? (
				<div className="totalPrice mx-auto text-right mt-10 w-full">
					<div className="celkovaCena font-medium mb-4">
						{t('cartFirst:total')}: {props.total} Kč
					</div>
					<button
						className="font-medium text-white bg-gray-600 w-32 py-1"
						type="submit"
						onClick={() => {
							props.setStep('firstToSecond');
							sessionStorage.setItem('step', '2');
							props.setKosikError('');
						}}
					>
						{t('cartFirst:continue')}
					</button>
				</div>
			) : (
				''
			)}
		</div>
	);
};

export default CartFirst;
