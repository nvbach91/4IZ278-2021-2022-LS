const MenuSpans = (props) => {
    return (
			<div
				className={
					props.menuActive
						? 'spans flex flex-col justify-center cursor-pointer activeSpans right-12 top-0'
						: 'spans flex flex-col justify-center cursor-pointer right-12 top-0'
				}
				onClick={() => {
					props.setMenuActive(!props.menuActive);
				}}
			>
				<span
					className={
						props.menuActive ? 'w-8 h-0.5 bg-white block' : 'w-8 h-0.5 bg-black block'
					}
				></span>
				<span
					className={
						props.menuActive
							? 'w-6 h-0.5 my-1 bg-white block'
							: 'w-6 h-0.5 my-1 bg-black block'
					}
				></span>
				<span
					className={
						props.menuActive ? 'w-8 h-0.5 bg-white block' : 'w-8 h-0.5 bg-black block'
					}
				></span>
			</div>
		);
}

export default MenuSpans;