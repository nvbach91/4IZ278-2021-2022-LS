import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import useTranslation from 'next-translate/useTranslation';

const CartSecond = props => {
	let { t } = useTranslation();
	const {
		handleSubmit,
		register,
		watch,
		setValue,
		formState: { errors },
	} = useForm();
	const [dataFromStorage, setDataFromStorage] = useState({});
	const [checkedInput, setCheckedInput] = useState(true);

	const changeHandler = () => {
		setCheckedInput(true);
	};

	// ziskani dat ze sessionStorage
	useEffect(() => {
		if (sessionStorage.getItem('personal_data')) {
			setDataFromStorage(JSON.parse(sessionStorage.getItem('personal_data')));
		}
	}, []);

	useEffect(() => {
		if (dataFromStorage) {
			Object.entries(dataFromStorage).forEach(element => {
				setValue(element[0], element[1], { shouldValidate: true });
			});
		}
	}, [dataFromStorage]);

	// ukladani do sessionStorage
	useEffect(() => {
		const subscription = watch(value =>
			sessionStorage.setItem('personal_data', JSON.stringify(value)),
		);
		return () => subscription.unsubscribe();
	}, [watch]);

	const onSubmit = () => {
		props.setStep('secondToThird');
		sessionStorage.setItem('step', '3');
	};

	return (
		<div
			className={
				'mainBox__second lg:my-24 my-12 mx-auto xl:w-4/6 lg:w-5/6 w-6/6 text-center hidden'
			}
			ref={props.secondBox}
		>
			<div className="w-full mx-auto">
				<form onSubmit={handleSubmit(onSubmit)}>
					<div className="bg-white shadow-2xl d:px-10 px-4 py-6 w-full mx-auto">
						<div className="flex flex-col md:flex-row">
							<div className="w-full md:mr-2 mr-0">
								<input
									className="font-medium md:h-12 h-8 appearance-none w-full py-2 border-b border-gray-600 text-gray-800 leading-tight focus:outline-none focus:shadow-outline"
									id="first_name"
									name="first_name"
									type="text"
									placeholder={t('cartSecond:firstNamePlaceholder') + ':'}
									{...register('first_name', { required: true })}
								/>
								<div className="md:h-9 h-6">
									{errors.first_name &&
										errors.first_name.type === 'required' && (
											<p className="h-6 text-left text-red-500 mb-1 err leading-6">
												{t('cartSecond:firstNameErr')}
											</p>
										)}
								</div>
							</div>
							<div className="w-full md:ml-2 ml-0">
								<input
									className="font-medium md:h-12 h-8 appearance-none w-full py-2 border-b border-gray-600 text-gray-800 leading-tight focus:outline-none focus:shadow-outline"
									id="last_name"
									name="last_name"
									type="text"
									placeholder={t('cartSecond:lastNamePlaceholder') + ':'}
									{...register('last_name', { required: true })}
								/>
								<div className="md:h-9 h-6">
									{errors.last_name && errors.last_name.type === 'required' && (
										<p className="h-6 text-left text-red-500 mb-1 err leading-6">
											{t('cartSecond:lastNameErr')}
										</p>
									)}
								</div>
							</div>
						</div>
						<div className="flex flex-col md:flex-row w-full">
							<div className="md:mr-2 mr-0 w-full">
								<input
									className="font-medium md:h-12 h-8 appearance-none w-full py-2 border-b border-gray-600 text-gray-800 leading-tight focus:outline-none focus:shadow-outline"
									id="email"
									name="email"
									type="text"
									placeholder="Email:"
									{...register('email', {
										required: 'Required',
										pattern: {
											value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
											message: `${t('cartSecond:emailPatternErr')}`,
										},
									})}
								/>
								<div className="md:h-9 h-6">
									{errors.email && errors.email.type === 'pattern' && (
										<p className="h-6 text-left text-red-500 mb-1 err leading-6">
											{errors.email.message}
										</p>
									)}

									{errors.email && errors.email.type === 'required' && (
										<p className="h-6 text-left text-red-500 mb-1 err leading-6">
											{t('cartSecond:emailRequiredErr')}
										</p>
									)}
								</div>
							</div>
							<div className="md:ml-2 ml-0 w-full">
								<input
									className="font-medium md:h-12 h-8 appearance-none w-full py-2 border-b border-gray-600 text-gray-800 leading-tight focus:outline-none focus:shadow-outline"
									id="phone"
									name="phone"
									type="text"
									placeholder={t('cartSecond:phoneNumberPlaceholder') + ':'}
									{...register('phone', {
										required: true,
										pattern: {
											value: /^[0-9\s]*$/,
											message: `${t('cartSecond:phoneNumberPatternError')}`,
										},
									})}
								/>
								<div className="md:h-9 h-6">
									{errors.phone && errors.phone.type === 'pattern' && (
										<p className="h-6 text-left text-red-500 mb-1 err leading-6">
											{errors.phone.message}
										</p>
									)}

									{errors.phone && errors.phone.type === 'required' && (
										<p className="h-6 text-left text-red-500 mb-1 err leading-6">
											{t('cartSecond:phoneNumberRequiredError')}
										</p>
									)}
								</div>
							</div>
						</div>
						<div className="flex flex-col md:flex-row">
							<div className="md:mr-2 mr-0 md:w-2/3 w-full">
								<input
									className="font-medium md:h-12 h-8 appearance-none w-full py-2 border-b border-gray-600 text-gray-800 leading-tight focus:outline-none focus:shadow-outline"
									id="street"
									name="street"
									type="text"
									placeholder={t('cartSecond:streetPlaceholder') + ':'}
									{...register('street', { required: true })}
								/>
								<div className="md:h-9 h-6">
									{errors.street && errors.street.type === 'required' && (
										<p className="h-6 text-left text-red-500 mb-1 err leading-6">
											{t('cartSecond:streetError')}
										</p>
									)}
								</div>
							</div>
							<div className="md:ml-2 ml-0 md:w-1/3 w-full">
								<input
									className="font-medium md:h-12 h-8 appearance-none w-full py-2 border-b border-gray-600 text-gray-800 leading-tight focus:outline-none focus:shadow-outline"
									id="house_number"
									name="house_number"
									type="text"
									placeholder={t('cartSecond:houseNumberPlaceholder') + ':'}
									{...register('house_number', { required: true })}
								/>
								<div className="md:h-9 h-6">
									{errors.house_number &&
										errors.house_number.type === 'required' && (
											<p className="h-6 text-left text-red-500 mb-1 err leading-6">
												{t('cartSecond:houseNumberErr')}
											</p>
										)}
								</div>
							</div>
						</div>
						<div className="md:mr-2 mr-0 w-full">
							<input
								className="font-medium md:h-12 h-8 appearance-none w-full py-2 border-b border-gray-600 text-gray-800 leading-tight focus:outline-none focus:shadow-outline"
								id="town"
								name="town"
								type="text"
								placeholder={t('cartSecond:townPlaceholder') + ':'}
								{...register('town', { required: true })}
							/>
							<div className="md:h-9 h-6">
								{errors.town && errors.town.type === 'required' && (
									<p className="h-6 text-left text-red-500 mb-1 err leading-6">
										{t('cartSecond:townErr')}
									</p>
								)}
							</div>
						</div>
						<div className="flex flex-col md:flex-row">
							<div className="md:mr-2 mr-0 w-full">
								<input
									className="font-medium md:h-12 h-8 appearance-none w-full py-2 border-b border-gray-600 text-gray-800 leading-tight focus:outline-none focus:shadow-outline"
									id="postal_code"
									name="postal_code"
									type="text"
									placeholder={t('cartSecond:postalCodePlaceholder') + ':'}
									{...register('postal_code', {
										required: true,
										pattern: {
											value: /^[0-9\s]*$/,
											message: `${t('cartSecond:postalCodePatternErr')}`,
										},
									})}
								/>
								<div className="md:h-9 h-6">
									{errors.postal_code &&
										errors.postal_code.type === 'pattern' && (
											<p className="h-6 text-left text-red-500 mb-1 err leading-6">
												{errors.postal_code.message}
											</p>
										)}
									{errors.postal_code &&
										errors.postal_code.type === 'required' && (
											<p className="h-6 text-left text-red-500 mb-1 err leading-6">
												{t('cartSecond:postalCodeRequiredErr')}
											</p>
										)}
								</div>
							</div>
							<div className="md:mr-2 mr-0 w-full">
								<input
									className="font-medium md:h-12 h-8 appearance-none w-full py-2 border-b border-gray-600 text-gray-800 leading-tight focus:outline-none focus:shadow-outline"
									id="coupon"
									name="coupon"
									type="text"
									placeholder={t('cartSecond:coupon') + ':'}
									{...register('coupon', {
										required: false,
									})}
								/>
							</div>
						</div>
						<div className="md:mr-2 mr-0 w-full">
							<textarea
								className="note font-medium md:h-12 h-8 appearance-none w-full py-2 border-b border-gray-600 text-gray-800 leading-tight focus:outline-none focus:shadow-outline"
								id="note"
								name="note"
								type="text"
								placeholder={t('cartSecond:note') + ':'}
								{...register('note', { required: false })}
							/>
							{/* <div className="md:h-9 h-6">
								{errors.note && errors.note.type === 'required' && (
									<p className="h-6 text-left text-red-500 mb-1 err leading-6">
										{t('cartSecond:noteErr')}
									</p>
								)}
							</div> */}
						</div>
						<div className="platba flex my-4 items-center md:mx-2 mx-0 ">
							<div className="font-medium text-gray-800 w-20 text-left">
								{t('cartSecond:payment')}:
							</div>
							<div className="flex flex-row md:px-2 px-0">
								<label className="px-1 relative overflow-hidden cursor-pointer">
									<input
										type="radio"
										name="payment"
										value="card"
										className="absolute"
										defaultChecked={checkedInput}
										onChange={changeHandler}
									/>
									<span className="flex align-middle">
										{t('cartSecond:creditCart')}
									</span>
								</label>
							</div>
						</div>
						<div className="doprava flex my-4 items-center md:mx-2 mx-0 ">
							<div className="font-medium text-gray-800 w-20 text-left">
								{t('cartSecond:delivery')}:
							</div>
							<div className="flex md:flex-row flex-col">
								<div className="flex md:px-2 px-0">
									<label className="px-1 relative overflow-hidden cursor-pointer">
										<input
											type="radio"
											name="payment"
											value={t('cartSecond:delivery1')}
											className="absolute"
											defaultChecked={true}
											{...register('delivery', {
												required: true,
											})}
										/>
										<span className="flex align-middle">
											{t('cartSecond:czechPost')}&nbsp;-&nbsp;99&nbsp;Kč
										</span>
									</label>
								</div>
								<div className="flex flex-row md:px-2 px-0">
									<label className="px-1 relative overflow-hidden cursor-pointer">
										<input
											type="radio"
											name="payment"
											value={t('cartSecond:delivery2')}
											className="absolute"
											{...register('delivery', {
												required: true,
											})}
										/>
										<span className="flex align-middle">
											{t('cartSecond:mailroom')}&nbsp;-&nbsp;89&nbsp;Kč
										</span>
									</label>
								</div>
							</div>
						</div>
					</div>
					<div className="mx-auto text-right mt-10 w-full flex justify-between">
						<button
							className="font-medium text-white bg-gray-600 w-32 py-1"
							onClick={() => {
								props.setStep('secondToFirst');
								sessionStorage.setItem('step', '1');
							}}
							type="button"
						>
							{t('cartSecond:backBtn')}
						</button>
						<button
							className="font-medium text-white bg-gray-600 w-32 py-1"
							type="submit"
						>
							{t('cartSecond:continueBtn')}
						</button>
					</div>
				</form>
			</div>
		</div>
	);
};

export default CartSecond;
