// react hooks
import { useEffect, useState, useRef } from 'react';
import useTranslation from 'next-translate/useTranslation';
import { useRouter } from 'next/router';

// links and routes
import * as ROUTES from '../constants/routes';
import Link from 'next/link';

// logo
import logo from '../public/images/logo.png';
import basket from '../public/images/basket.png';
import register from '../public/images/user.png';
import image from '/public/images/cart2.png';

// animations
import { gsap } from 'gsap';

// components
import MenuSpans from '../components/menuSpans';

// context
import { useMainContext } from '../context/mainContext.js';

const Navbar = ({ user }) => {
	const { pathname } = useRouter();
	const [windowScroll, setWindowScroll] = useState(0);
	const [menuActive, setMenuActive] = useState(false);
	const { windowWidth } = useMainContext();
	const { logged } = useMainContext();
	let { t } = useTranslation();
	const router = useRouter();

	const links = [
		{
			id: 1,
			name: `${t('navbar:links-bitcoin')}`,
			link: `/produkty/bitcoin_pasek`,
		},
		{
			id: 2,
			name: `${t('navbar:links-ethereum')}`,
			link: `/produkty/ethereum_pasek`,
		},
		{ id: 3, name: `${t('navbar:links1')}`, link: `${ROUTES.ABOUT}` },
		{ id: 4, name: `${t('navbar:links2')}`, link: `${ROUTES.CONTACT}` },
	];

	const mobileLinks = [
		{
			id: 1,
			name: `${t('navbar:links-bitcoin')}`,
			link: `/produkty/bitcoin_pasek`,
		},
		{
			id: 2,
			name: `${t('navbar:links-ethereum')}`,
			link: `/produkty/ethereum_pasek`,
		},
		{ id: 3, name: `${t('navbar:links1')}`, link: `${ROUTES.ABOUT}` },
		{ id: 4, name: `${t('navbar:links2')}`, link: `${ROUTES.CONTACT}` },
		{ id: 5, name: `${t('navbar:links4')}`, link: `${ROUTES.CART}` },
		{ id: 6, name: `${t('navbar:links3')}`, link: `${ROUTES.REGISTER}` },
	];

	// refs for animation
	const mobileMenu = useRef();
	const refsLi = useRef([]);
	const addToRefsLi = el => {
		if (el && !refsLi.current.includes(el)) {
			refsLi.current.push(el);
		}
	};

	// box shadow
	const handleScroll = () => {
		setWindowScroll(window.scrollY);
	};

	useEffect(() => {
		window.addEventListener('scroll', handleScroll);
		return () => window.removeEventListener('scroll', handleScroll);
	});

	// mobile menu animations
	const menuActiveAnimation = () => {
		if (menuActiveAnimation) {
			const links = () => {
				refsLi.current.forEach(element => {
					if (refsLi.current.indexOf(element) === 0) {
						gsap.fromTo(
							element,
							{
								y: 90,
								opacity: 0,
								ease: 'Sine.easeOut',
								duration: 0.4,
								delay: 2,
							},
							{ y: 0, opacity: 1, ease: 'Sine.easeOut', duration: 0.4 },
						);
					} else {
						gsap.fromTo(
							element,
							{
								y: 90,
								opacity: 0,
								ease: 'Sine.easeOut',
								duration: 0.4,
							},
							{ y: 0, opacity: 1, ease: 'Sine.easeOut', duration: 0.4 },
						);
					}
				});
			};
			gsap.fromTo(
				mobileMenu.current,
				{
					opacity: 0,
					display: 'none',
					duration: 0.05,
				},
				{
					opacity: 1,
					display: 'flex',
					duration: 0.05,
					onComplete: function () {
						gsap.fromTo(
							mobileMenu.current,
							{
								x: '100vw',
							},
							{
								x: 0,
								onComplete: function () {
									links();
								},
							},
						);
					},
				},
			);
		}
	};

	let tl = gsap.timeline();
	const menuNotActiveAnimation = () => {
		const menuReversed = () => {
			gsap.to(mobileMenu.current, {
				x: '100vw',
				onComplete: function () {
					gsap.to(mobileLinks.current, {
						opacity: 0,
						display: 'none',
					});
				},
			});
		};
		refsLi.current.forEach(element => {
			tl.to(
				element,
				{
					y: 90,
					opacity: 0,
					ease: 'Sine.easeOut',
					duration: 0.4,
					onComplete: function () {
						if (refsLi.current.indexOf(element) === refsLi.current.length - 1) {
							menuReversed();
						}
					},
				},
				'<',
			);
		});
	};

	useEffect(() => {
		if (mobileMenu.current && refsLi.current) {
			if (menuActive) {
				menuActiveAnimation();
			} else {
				menuNotActiveAnimation();
			}
		}
	}, [menuActive]);

	useEffect(() => {
		if (windowWidth > 1024) {
			setMenuActive(false);
		}
	}, [windowWidth]);

	const [circleText, setCircleText] = useState();
	const circle = useRef();
	const circleH1 = useRef();
	const menuEnterFunction = name => {
		gsap.to(circle.current, { opacity: 0.05 });
		setCircleText(name);
		gsap.fromTo(
			circleH1.current,
			{
				letterSpacing: '20px',
			},
			{
				letterSpacing: '2px',
			},
		);
	};

	const circleFunc = () => {
		gsap.to(circle.current, { opacity: 0 });
		setCircleText('');
	};

	const circleRef = useRef();
	const refsLi2 = useRef([]);
	const addToRefsLi2 = el => {
		if (el && !refsLi2.current.includes(el)) {
			refsLi2.current.push(el);
		}
	};

	useEffect(() => {
		if (circleRef.current) {
			gsap.to(circleRef.current, {
				top:
					refsLi2.current[0].offsetTop +
					refsLi2.current[0].getBoundingClientRect().height,
			});
		}
	}, [windowWidth]);

	const menuMouseEnter = (e, id) => {
		if (e.target) {
			gsap.to(circleRef.current, {
				opacity: 1,
				left: e.target.offsetLeft + e.target.getBoundingClientRect().width / 2,
			});
		} else {
			gsap.to(circleRef.current, {
				opacity: 1,
				left:
					refsLi2.current[id].offsetLeft +
					refsLi2.current[id].getBoundingClientRect().width / 2,
			});
		}
	};

	const menuMouseLeave = () => {
		gsap.to(circleRef.current, {
			opacity: 0,
			left: 0,
		});
	};

	let price = 0;
	if (typeof window !== 'undefined' && sessionStorage.getItem('products')) {
		JSON.parse(sessionStorage.getItem('products')).forEach(element => {
			price += Number(element.price) * Number(element.quantity);
		});
	}

	// vycentrovani menu
	const linksRef = useRef();
	const [linksWidth, setLinksWidth] = useState(0);
	useEffect(() => {
		if (linksRef.current) {
			setLinksWidth(linksRef.current.getBoundingClientRect().width);
		}
	}, [linksRef.current, windowWidth]);

	return (
		<>
			<MenuSpans menuActive={menuActive} setMenuActive={setMenuActive} />
			<div
				className={
					windowScroll >= 20
						? 'navbar bg-white fixed top-0 left-0 w-full h-32 boxShadow'
						: 'navbar bg-white fixed top-0 left-0 w-full h-32'
				}
			>
				<div className="navbar-container flex justify-between h-full z-40">
					<Link href={`${ROUTES.UVOD}`}>
						<a className="h-full" style={{ width: windowWidth > 1400 ? linksWidth + 'px' : 'auto' }}>
							<div className="logo flex items-center h-full">
								<img alt="logo" src={logo.src} />
							</div>
						</a>
					</Link>
					<div className="links flex items-center py-4 mainlinks">
						<ul
							className="flex h-full items-center gap-8"
							onMouseLeave={() => {
								menuMouseLeave();
							}}
						>
							{links.map((item, index) => {
								const { id, name, link } = item;
								// if (!user.id) return null;
								return (
									<li
										key={id}
										ref={addToRefsLi2}
										onMouseEnter={e => {
											menuMouseEnter(e, index);
										}}
									>
										<Link href={link}>
											<a>{name}</a>
										</Link>
									</li>
								);
							})}
							<div className="circle" ref={circleRef} />
						</ul>
					</div>
					<div className="flex" ref={linksRef}>
						<div className="clippath bg-black">
							<Link
								href={
									logged !== ""
										? logged === 'user'
											? ROUTES.LOGOUT
											: ROUTES.ADMIN_PRODUCTS
										: ROUTES.REGISTER
								}
							>
								<a>
									<div
										className={
											router.locale === 'cs'
												? 'flex mainlinks mainRegister'
												: 'flex mainlinks mainRegister'
										}
									>
										<div className="register2" />
										<div className="text-white p-8 register flex">
											<div
												className={
													'lg:flex flex-col items-center justify-center'
												}
											>
												<div className="register_div">
													<img src={register.src} alt="register" />
												</div>
												<span>
													{logged
														? logged === 'user'
															? t('navbar:login_user')
															: t('navbar:login_admin')
														: t('navbar:links3')}
												</span>
											</div>
										</div>
									</div>
								</a>
							</Link>
						</div>
						<div className="cartMain relative bg-black basket">
							<div className="absolute bg-black -left-1/2 w-full h-full blackbox" />
							<Link href={ROUTES.CART} className="py-4">
								<a>
									<div className="links2 flex flex-col items-center justify-center  text-white p-8 mainlinks">
										<div
											className="basket_div"
											data={
												typeof window !== 'undefined' &&
												sessionStorage.getItem('products')
													? JSON.parse(sessionStorage.getItem('products'))
															.length
													: '0'
											}
										>
											<img src={basket.src} alt="basket" />
										</div>
										<span>{t('navbar:links4')}</span>
									</div>
								</a>
							</Link>
							{sessionStorage.getItem('products') &&
								sessionStorage.getItem('products') !== '[]' && (
									<div className="cartList">
										<div className="cartList-container">
											<div className="cartList-container-header flex justify-between items-center">
												<div className="flex items-center">
													<Link href={ROUTES.CART}>
														<a>
															<img
																src={image.src}
																alt="cart"
																className="w-9 h-auto object-contain mr-1"
															/>
														</a>
													</Link>
													<span className="amount">
														{sessionStorage.getItem('products')
															? JSON.parse(sessionStorage.getItem('products'))
																	.length
															: ''}
													</span>
												</div>
												<div className="flex items-center info">
													<span className="light-text pr-1">
														{t('cartList:total')}:
													</span>
													<span className="total">{price} Kč</span>
												</div>
											</div>
											<div className="products">
												{sessionStorage.getItem('products') &&
												sessionStorage.getItem('products') !== '[]'
													? JSON.parse(sessionStorage.getItem('products')).map(
															(item, index) => {
																const { id, title, quantity, price } = item;
																return (
																	<div
																		className="items__item relative flex gap-6 text-left items-center justify-between py-6 px-4"
																		id={id}
																		key={index}
																	>
																		<div className="index">{index + 1}</div>
																		<div className="w-full xl:text-right md:text-left text-right cena xl:mt-0 mt-3">
																			<h1 className="font-bold text-left title">
																				{title}
																			</h1>
																			<div className="flex items-center gap-3 justify-start">
																				<h6>
																					{price} Kč / 1 {t('cartList:item')}
																				</h6>
																				<h6>
																					{t('cartList:amount')}: {quantity}
																				</h6>
																			</div>
																		</div>
																	</div>
																);
															},
													  )
													: null}
											</div>
											<div className="flex justify-center text-center">
												<Link href={ROUTES.CART}>
													<a className="w-full button">
														{t('cartList:button')}
													</a>
												</Link>
											</div>
										</div>
									</div>
								)}
						</div>
					</div>
				</div>
			</div>
			<div
				className="hidden mobileMenu w-screen h-screen text-white items-center justify-center fixed top-0 left-0 z-40 bg-black"
				ref={mobileMenu}
			>
				<div className="circle" ref={circle} />
				<h1 className="circle_h1" ref={circleH1}>
					{circleText}
				</h1>
				<ul
					className="flex flex-col gap-6 text-center"
					onMouseLeave={() => {
						circleFunc();
					}}
				>
					{mobileLinks.map(item => {
						const { id, name, link } = item;
						return (
							<li
								key={id}
								className={
									pathname === '/' && link === '/'
										? 'activeMobile'
										: pathname.includes(link) &&
										  link !== '/' &&
										  !pathname.includes('admin')
										? 'activeMobile'
										: ''
								}
								ref={addToRefsLi}
								onClick={() => {
									setMenuActive(!menuActive);
								}}
								onMouseEnter={() => {
									menuEnterFunction(
										id !== 6
											? name
											: logged
											? logged === 'user'
												? t('navbar:login_user').toLowerCase()
												: t('navbar:login_admin').toLowerCase()
											: t('navbar:links3'),
									);
								}}
							>
								<Link
									href={
										id !== 6
											? link
											: logged !== ''
											? logged === 'user'
												? ROUTES.LOGOUT
												: ROUTES.ADMIN_PRODUCTS
											: ROUTES.REGISTER
									}
								>
									<a>
										{id !== 6
											? name
											: logged
											? logged === 'user'
												? (t('navbar:login_user')).toLowerCase()
												: (t('navbar:login_admin')).toLowerCase()
											: t('navbar:links3')}
									</a>
								</Link>
							</li>
						);
					})}
				</ul>
			</div>
		</>
	);
};

export default Navbar;
