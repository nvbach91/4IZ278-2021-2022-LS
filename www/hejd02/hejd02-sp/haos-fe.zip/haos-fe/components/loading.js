import React, { useRef, useEffect } from 'react';
import { ADDRESS } from '../constants/routes';
import Head from 'next/head';
import useTranslation from 'next-translate/useTranslation';
import gsap from 'gsap';

// icon
import icon from '../public/favicon.ico';

const Loading = () => {
	let { t } = useTranslation();
	const heading = useRef();
	useEffect(() => {
		if (heading.current) {
			gsap.to(heading.current, {
				color: `rgba(29, 29, 31, ${Math.random()})`,
				repeat: -1,
				yoyo: true,
				duration: 0.95,
			});
		}
	}, [heading.current]);
	return (
		<div className="h-screen w-screen bg-white flex justify-center items-center absolute top-0 left-0">
			<Head>
				<link rel="icon" href={icon.src} />
				<link rel="apple-touch-icon" href={icon.src} />
				<link rel="manifest" href="../public/manifest.json" />
				<title>{`HaoS.store | ${t('loading:text')}`}</title>
				<meta name="theme-color" content="#144474" />
				<meta
					name={'description'}
					content={'Kvalitní a jedinečné kožené opasky s crypto tématikou.'}
				/>
				<meta name={'robots'} content={false} />
				<meta property="og:type" content={'website'} />
				<meta
					property="og:title"
					content={`HaoS.store | ${t('loading:text')}`}
				/>
				<meta
					property="og:description"
					content={'Kvalitní a jedinečné kožené opasky s crypto tématikou.'}
				/>
				{/* <meta
					property="og:image"
					content="http://hejnadaniel.cz/logoVyresme.png"
				/> */}
				<meta property="og:url" content={ADDRESS} />
				<meta property="og:site_name" content="Haos.store.cz" />
			</Head>
			<div className="container">
				<h1 className="font-black" ref={heading}>
					Haos
				</h1>
			</div>
		</div>
	);
};

export default Loading;
