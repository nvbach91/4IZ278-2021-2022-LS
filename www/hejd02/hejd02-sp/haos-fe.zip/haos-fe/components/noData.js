import useTranslation from 'next-translate/useTranslation';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from './Animations';

const NoData = props => {
	let { t } = useTranslation();
	return (
		<motion.div
			variants={pageAnimation}
			initial="hidden"
			animate="enter"
			exit="exit"
			transition={{ type: 'linear' }}
			className="noDataContainer xl:pt-48 pt-28"
		>
			<div className="noData xl:pb-24 lg:pb-12 pt-6 pb-12 xl:px-24 lg:px-16 md:px-12 px-4 mx-auto">
				<div className="noData-wrapper text-center sm:p-8 px-4 py-6 mx-auto">
					<div className="noData-wrapper-text my-6">
						{props.productsErr
							? `${t('noData:productsErr')}`
							: props.messagesErr
							? `${t('noData:messagesErr')}`
							: props.ordersErr
							? `${t('noData:ordersErr')}`
							: `${t('noData:emailsErr')}`}
					</div>
				</div>
			</div>
		</motion.div>
	);
};

export default NoData;
