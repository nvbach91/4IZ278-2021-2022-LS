import { useEffect, useState } from 'react';
import useTranslation from 'next-translate/useTranslation';

import { motion } from 'framer-motion';

import Link from 'next/link';
import * as ROUTES from '../constants/routes';

interface ActiveSideBar {
	activeSideBar: boolean;
}

export default function Sidebar(props: ActiveSideBar) {
	let { t } = useTranslation();
	const links = [
		{
			id: 1,
			name: `${t('aminSidebar:item1')}`,
			to: `${ROUTES.ADMIN_PRODUCTS}`,
		},
		{
			id: 2,
			name: `${t('aminSidebar:item2')}`,
			to: `${ROUTES.ADMIN_MESSAGES}`,
		},
		{ id: 3, name: `${t('aminSidebar:item3')}`, to: `${ROUTES.ADMIN_USERS}` },
		{ id: 4, name: `${t('aminSidebar:item4')}`, to: `${ROUTES.ADMIN_EMAILS}` },
		{ id: 5, name: `${t('aminSidebar:item5')}`, to: `${ROUTES.ADMIN_ORDERS}` },
		{ id: 6, name: `${t('aminSidebar:item6')}`, to: `${ROUTES.LOGOUT}` },
	];

	const animateSidebar = {
		hidden: {
			height: '0rem',
			transition: {
				duration: 0.5,
				ease: 'easeInOut',
			},
		},
		show: {
			height: '100%',
			transition: {
				duration: 0.5,
				ease: 'easeInOut',
			},
		},
	};

	const [path, setPath] = useState('');
	useEffect(() => {
		if (typeof window !== 'undefined') {
			setPath(window.location.pathname);
		}
	}, []);

	return (
		<motion.div
			variants={animateSidebar}
			animate={props.activeSideBar ? 'show' : 'hidden'}
			initial="hidden"
			className="sidebar"
		>
			<ul>
				{links.map((val: any, key: number) => {
					return (
						<li key={key}>
							<Link key={key} href={val.to}>
								<a id={path.includes(val.to) && path.includes("admin") ? 'active' : ''}>{val.name}</a>
							</Link>
						</li>
					);
				})}
			</ul>
		</motion.div>
	);
}
