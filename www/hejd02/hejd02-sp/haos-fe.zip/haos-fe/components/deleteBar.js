import gsap from 'gsap';
import { useRef } from 'react';
import useTranslation from 'next-translate/useTranslation';

const DeleteBar = ({
	showTheBar,
	setDeleteItem,
	setShowTheBar,
}) => {
	const deleteBarRef = useRef();
	let { t } = useTranslation();
	if (showTheBar && deleteBarRef.current) {
		gsap.to(deleteBarRef.current, {
			opacity: 1,
			duration: 0.7,
			width: 'fit-content',
		});
	}
	const hideTheBar = props => {
		if (deleteBarRef.current) {
			gsap.to(deleteBarRef.current, {
				opacity: 0,
				duration: 0.7,
				width: 0,
				onComplete: function () {
					setShowTheBar(false);
					if (props === 'ano') {
						setDeleteItem(true);
					}
				},
			});
		}
	};
	return (
		<div className="fixed delete-bar" ref={deleteBarRef}>
			<div className="delete-bar-container p-6 flex flex-col justify-center items-center">
				<h1>{t('deleteBar:text')}</h1>
				<div className="buttons flex gap-5 justify-center items-center mt-5">
					<button
						className="px-5 py-1 uppercase"
						onClick={() => {
							hideTheBar('ano');
						}}
					>
						{t('deleteBar:btn1')}
					</button>
					<button
						className="px-5 py-1 uppercase"
						onClick={() => {
							hideTheBar('ne');
						}}
					>
						{t('deleteBar:btn2')}
					</button>
				</div>
			</div>
		</div>
	);
};

export default DeleteBar;
