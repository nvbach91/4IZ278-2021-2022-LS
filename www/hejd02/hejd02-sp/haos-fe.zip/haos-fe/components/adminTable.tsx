import React, { useEffect, useState } from 'react';
import ITable from '../interfaces/table';
// @ts-ignore
import $ from 'jquery';
import Link from 'next/link';
import axios from 'axios';
import { ADDRESS } from '../constants/routes';
import DeleteBar from '../components/deleteBar';
import useTranslation from 'next-translate/useTranslation';

const AdministrationTable: React.FunctionComponent<ITable> = (props: {
	buttons: any[] | null;
	type: string;
	thead: any[];
	tbody: any[];
	colgroup: any[];
	table: any;
	additionalContent: any[] | null;
	wantedParams: any[];
	additionalContentTXT: any[] | null;
	update?;
}) => {
	const [showTheBar, setShowTheBar] = useState(false);
	const [deleteItem, setDeleteItem] = useState(false);
	const [tableUseState, setTableUseState] = useState('');
	const [idUseState, setIdUseState] = useState('');
	const [keyUseState, setKeyUseState] = useState('');
	let { t } = useTranslation();

	const deleteEvent = async () => {
		axios
			.delete(`${ADDRESS}/admin/${tableUseState}/${idUseState}`, {
				headers: {
					Authorization: 'Bearer ' + localStorage.getItem('token'),
				},
			})
			.then(res => {
				let basicChild = document.getElementById('basicChild' + idUseState);
				props.update();
				if (basicChild) {
					basicChild.style.display = 'none';
				}
			});
	};

	const unpackEvent: any = (id: string, index: number) => {
		let x = document.querySelectorAll('.transitionRow');
		let y = document.querySelectorAll('.unpack');
		for (let i = 0; i < x.length; i++) {
			if (i !== index) {
				x[i].classList.add('hiddenRow');
				$(y[i]).text(`${t('adminTable:unpack')}`);
			}
		}
		const row = document.getElementById(id);
		let btn = document.getElementById('unpack' + id);

		if (row === null || btn === null) {
			return;
		}

		if (row.classList.contains('hiddenRow')) {
			btn.innerText = `${t('adminTable:unpacked')}`;
			return row.classList.remove('hiddenRow');
		} else {
			btn.innerText = `${t('adminTable:unpack')}`;
			return row.classList.add('hiddenRow');
		}
	};

	const invoiceEvent: any = (id: string) => {
		window.open(`${ADDRESS}/order/invoice/${id}`);
	};

	const buttonEvent = (
		id: string,
		key: string,
		type: string,
		table: string,
		index: number,
		url: string,
	) => {
		if (type === 'delete') {
			setShowTheBar(true);
			setIdUseState(id);
			setKeyUseState(key);
			setTableUseState(table);
		} else if (type === 'unpack') {
			unpackEvent(id, index);
		} else if (type === 'invoice') {
			invoiceEvent(id);
		}
	};

	useEffect(() => {
		if (deleteItem) {
			deleteEvent();
		}
	}, [deleteItem]);

	const buttons = (id: string, indexX: number) => {
		if (props.buttons !== null) {
			return props.buttons.map((button, index) => {
				if (button.type !== 'edit') {
					return (
						<td key={index}>
							<button
								id={button.type + id}
								key={index}
								onClick={() =>
									buttonEvent(
										id,
										button.key,
										button.type,
										button.table,
										indexX,
										button.table,
									)
								}
								className={'btn ' + button.type}
							>
								{button.name}
							</button>
						</td>
					);
				} else {
					return (
						<td key={index}>
							<Link href={button.url + id}>
								<a id={button.type + id} className={'btn ' + button.type}>
									{button.name}
								</a>
							</Link>
						</td>
					);
				}
			});
		} else {
			return null;
		}
	};

	const additionalRow = (
		id: any,
		content: any[] | null,
		contentTxT: any[] | null,
		indexOMEGA: any,
	) => {
		if (props.type === 'addedRow') {
			if (content && contentTxT)
				return (
					<tr id={id} className={'transitionRow hiddenRow'}>
						<td colSpan={props.thead.length}>
							<div>
								{content.map((content, index) => {
									return (
										<div key={index}>
											<p>
												{contentTxT[index]}{' '}
												<span className={'additional'}>
													{content === 'user_name'
														? `${props.tbody[indexOMEGA].user.first_name} ${props.tbody[indexOMEGA].user.last_name}`
														: content === 'user_phone'
														? props.tbody[indexOMEGA].user.phone
														: content === 'user_email'
														? props.tbody[indexOMEGA].user.email
														: content === 'address'
														? `${props.tbody[indexOMEGA].address[0].street},  ${props.tbody[indexOMEGA].address[0].street_number}, ${props.tbody[indexOMEGA].address[0].town}, ${props.tbody[indexOMEGA].address[0].region}, ${props.tbody[indexOMEGA].address[0].zip}`
														: content === 'products'
														? props.tbody[indexOMEGA].products[0].map(item => {
																return `Product_id: ${item.product_id}, size_id: ${item.size_id} , quantity: ${item.pivot.product_quantity}; `;
														  })
														: props.tbody[indexOMEGA][content]}
												</span>
											</p>
										</div>
									);
								})}
							</div>
						</td>
					</tr>
				);
		} else if (props.type !== 'addedRow') {
			return null;
		}
	};

	return (
		<>
			<DeleteBar
				showTheBar={showTheBar}
				setDeleteItem={setDeleteItem}
				setShowTheBar={setShowTheBar}
			/>
			<table
				className={
					props.table === 'messages'
						? 'adminTable table-messages'
						: 'adminTable'
				}
			>
				<colgroup>
					{props.colgroup.map((colgroup, index) => (
						<col key={index} style={{ width: colgroup + '%' }} />
					))}
				</colgroup>
				<thead>
					<tr>
						{props.thead.map((thead, index) => (
							<th key={index}>{thead}</th>
						))}
					</tr>
				</thead>
				{props.tbody.length > 0 && (
					<tbody>
						{props.tbody.map((tbody, index) => {
							let rowName;
							if (props.additionalContent !== null) {
								rowName = 'additionalRow';
							} else {
								rowName = 'basicRow';
							}
							return (
								<React.Fragment key={index}>
									<tr id={'basicChild' + tbody.id} className={rowName}>
										{props.wantedParams.map((wanted, index) => {
											if (wanted === 'attributes') {
												return (
													<td key={index}>
														{tbody[wanted].created_at.slice(0, 10)}
													</td>
												);
											}
											if (wanted === 'product_name') {
												return (
													<td key={index}>
														{tbody['attributes'].product_name}
													</td>
												);
											}
											if (wanted === 'price') {
												return <td key={index}>{tbody['attributes'].price}</td>;
											}
											if (wanted === 'color') {
												return <td key={index}>{tbody['attributes'].color}</td>;
											}
											if (wanted === 'category') {
												return <td key={index}>{tbody[wanted].name}</td>;
											}
											if (wanted === 'user' && props.table === 'order') {
												return (
													<td
														key={index}
													>{`${tbody[wanted].first_name} ${tbody[wanted].last_name}`}</td>
												);
											}
											if (wanted === 'products') {
												tbody[wanted][0].map((item, index) => {
													const {
														product_id,
														product_size_id,
														remaining_quantity,
													} = item;
													return (
														<td key={index}>
															Product_id: {product_id}, product_size_id:{' '}
															{product_size_id}, quantity: {remaining_quantity}
														</td>
													);
												});
												return null;
											}
											return <td key={index}>{tbody[wanted]}</td>;
										})}
										{tbody.id
											? buttons(tbody.id, index)
											: tbody.product_id
											? buttons(tbody.product_id, index)
											: tbody['user_id ']
											? buttons(tbody['user_id '], index)
											: buttons(tbody['order_id'], index)}
									</tr>
									{additionalRow(
										tbody.id ? tbody.id : tbody.order_id,
										props.additionalContent,
										props.additionalContentTXT,
										index,
									)}
								</React.Fragment>
							);
						})}
					</tbody>
				)}
			</table>
		</>
	);
};

export default AdministrationTable;
