import React from 'react';
import Link from 'next/link';
import useTranslation from 'next-translate/useTranslation';

const CartFourth = props => {
	let { t } = useTranslation();
	return (
		<div
			className={
				'mainBox__fourth lg:my-32 my-20 mx-auto xl:w-4/6 lg:w-5/6 w-6/6text-center hidden'
			}
			ref={props.fourthBox}
		>
			<div className="bg-white shadow-2xl md:px-10 md:p-16 p-8 w-full mx-auto text-center font-medium">
				<h1>{t('cartFourth:thanks')}</h1>
				<p className="md:my-12 my-8">{t('cartFourth:confirmation')}</p>
				<Link href="/">
					<a>
						<button className="bg-gray-800 text-white p-3 uppercase font-medium rounded-lg w-auto">
							{t('cartFourth:button')}
						</button>
					</a>
				</Link>
			</div>
		</div>
	);
};

export default CartFourth;
