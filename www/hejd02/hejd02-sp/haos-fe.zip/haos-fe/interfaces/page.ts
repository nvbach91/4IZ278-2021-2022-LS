export default interface IPage {
	name: string;
	id: number;
	items: any;
	categories: any;
	currentBlog: any;
	fetchedCategories: any;
	currentStory: any;
}