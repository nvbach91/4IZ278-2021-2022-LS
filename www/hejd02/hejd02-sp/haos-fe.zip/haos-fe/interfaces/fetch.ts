export default interface IPage {
	url: string;
}
