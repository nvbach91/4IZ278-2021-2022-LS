export default interface ITable {
	type: string;
	colgroup: any[];
	thead: string[];
	tbody: any[];
	wantedParams: string[];
	buttons:
		| { name: string; type: string; table: string; key: string; url: string }[]
		| null;
	additionalContent: any[] | null;
	additionalContentTXT: any[] | null;
	messages: any;
	table: any;
}