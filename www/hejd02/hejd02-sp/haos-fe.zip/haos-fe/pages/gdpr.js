import React from 'react';
import useTranslation from 'next-translate/useTranslation';

// animations
import { pageAnimation } from '../components/Animations';
import { motion } from 'framer-motion';

// components
import Layout from '../components/layout';

export default function GDPR() {
	let { t } = useTranslation();
	return (
		<Layout
			title={t('SEO:gdpr.title')}
			metaDescription={t('SEO:gdpr.description')}
			robots={true}
			pageType={'website'}
		>
			<motion.div
				variants={pageAnimation}
				initial="hidden"
				animate="enter"
				exit="exit"
				transition={{ type: 'linear' }}
				className="mainWrapper z-1 gdpr"
			>
				<div className="mainContainer">
					<div className="gdpr-wrapper">
						<h1 className="font-semibold mb-7">{t('gdpr:heading1')}</h1>
						<div className="text md:mt-8 mt-5">
							<h3 className="font-semibold mb-3">{t('gdpr:heading2')}</h3>
							<p className="block mt-3">{t('gdpr:text1')}</p>
							<h6 className="font-semibold mt-5">{t('gdpr:heading3')}</h6>
							<ul className="mb-5">
								<li>{t('gdpr:address')}</li>
								<li>{t('gdpr:email')}</li>
							</ul>
							<p>
								{t('gdpr:text2')}
								<br />
								{t('gdpr:text3')}
								<br />
								{t('gdpr:text4')}
							</p>
							<h6 className="font-semibold mt-5">{t('gdpr:heading4')}</h6>
							<p>
								{t('gdpr:text5')}
								<br />
								{t('gdpr:text6')}
							</p>
						</div>
						<div className="text mt-8">
							<h3 className="font-semibold mb-3">{t('gdpr:heading5')}</h3>
							<h6 className="font-semibold mt-5">{t('gdpr:heading6')}</h6>
							<ul>
								<li>{t('gdpr:text7')}</li>
								<li>{t('gdpr:text8')}</li>
								<li>{t('gdpr:text9')}</li>
							</ul>
						</div>
						<div className="text mt-8">
							<h3 className="font-semibold mb-3">{t('gdpr:heading7')}</h3>
							<p className="mt-3">
								{t('gdpr:text10')} <br />
								{t('gdpr:text11')}
							</p>
							<h6 className="font-semibold mt-5">{t('gdpr:heading8')}</h6>
							{t('gdpr:text12')}
							<ul>
								<li>{t('gdpr:text13')}</li>
								<li>{t('gdpr:text14')}</li>
								<li>{t('gdpr:text15')}</li>
							</ul>
						</div>
						<div className="text mt-8">
							<h3 className="font-semibold mb-3">{t('gdpr:heading9')}</h3>
							<h6 className="font-semibold md:mt-5 mt-3">
								{t('gdpr:heading10')}
							</h6>
							<ul>
								<li>{t('gdpr:text16')}</li>
								<li>{t('gdpr:text17')}</li>
								<li>{t('gdpr:text18')}</li>
								<li>{t('gdpr:text19')}</li>
								<li>{t('gdpr:text20')}</li>
								<li>{t('gdpr:text21')}</li>
							</ul>
						</div>
					</div>
				</div>
			</motion.div>
		</Layout>
	);
}