import React from 'react';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { ADDRESS } from '../constants/routes';
import useTranslation from 'next-translate/useTranslation';

// animations
import { pageAnimation } from '../components/Animations';
import { motion } from 'framer-motion';

// components
import Layout from '../components/layout';

//photos
import facebook from '../public/images/facebook.png';
import instagram from '../public/images/instagram.png';
import emailPhoto from '../public/images/emailButton_image.svg';

import axios from 'axios';

export default function Contact() {
	let { t } = useTranslation();
	const {
		handleSubmit,
		register,
		reset,
		formState: { errors },
	} = useForm();

	const [succMsg, setSuccMsg] = useState('');
	const [errorMsg, setErrorMsg] = useState('');
	const [disabled, setDisabled] = useState(false);

	const onSubmit = async data => {
		setDisabled(true);
		axios
			.post(`${ADDRESS}/message`, data)
			.catch(err => {
				if (err) {
					setErrorMsg(`${t('contact:err')}`);
					setDisabled(false);
				}
			})
			.then(response => {
				if (response) {
					setSuccMsg(`${t('contact:succErr')}`);
					setDisabled(false);
					// reset();
				}
			});
		setTimeout(() => {
			setSuccMsg('');
			setErrorMsg('');
		}, 5000);
	};

	return (
		<Layout
			title={t('SEO:contact.title')}
			metaDescription={t('SEO:contact.description')}
			robots={true}
			pageType={'website'}
		>
			<motion.div
				variants={pageAnimation}
				initial="hidden"
				animate="enter"
				exit="exit"
				transition={{ type: 'linear' }}
				className="mainWrapper contacts"
			>
				<div className="flex justify-center positioning">
					<div className="flex flex-col">
						<div className="flex justify-center mb-3">
							<h1 className="font-medium">{t('contact:title')}</h1>
						</div>
						<div className="flex justify-center underTitle mb-4">
							<h3 className="text-center">{t('contact:subtitle')}</h3>
						</div>
						<div className="flex justify-center max-w-6xl mb-12">
							<p className="text-center">{t('contact:text')}</p>
						</div>
						<div className="flex justify-center items-center black gap-6 py-3">
							<a
								href="https://www.facebook.com/"
								target="_blank"
								rel="noreferrer"
							>
								<div className="flex justify-center items-center gap-3">
									<img src={facebook.src} alt="HaoS - Facebook" />
									<span>facebook</span>
								</div>
							</a>
							<a
								href="https://www.instagram.com/"
								target="_blank"
								rel="noreferrer"
							>
								<div className="flex justify-center items-center gap-3">
									<img src={instagram.src} alt="HaoS - Facebook" />
									<span>instagram</span>
								</div>
							</a>
						</div>
						<div className="flex justify-center">
							<h1 className="font-medium mt-24 text-center">
								{t('contact:title2')}
							</h1>
						</div>
						<div className="flex justify-center mt-12">
							<form
								onSubmit={handleSubmit(onSubmit)}
								className="flex justify-center"
							>
								<div className="form-wrapper">
									<div className="flex justify-center items-center flex-col mb-8">
										<input
											type="text"
											placeholder={t('contact:namePlaceholder')}
											className="sm:w-full xs:w-2/3 w-full mb-2 form_placeholder text-center"
											{...register('name', { required: true })}
										/>
										{errors.name && errors.name.type === 'required' && (
											<p className="h-6 text-left text-red-500 mb-2 err leading-6">
												{t('contact:nameError')}
											</p>
										)}
										<input
											type="text"
											placeholder="Email"
											className="sm:w-full xs:w-2/3 w-full mb-2 form_placeholder text-center"
											{...register('email', {
												required: 'Required',
												pattern: {
													value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
													message: `${t('contact:emailPatternError')}`,
												},
											})}
										/>
										{errors.email && errors.email.type === 'pattern' && (
											<p className="h-6 text-left text-red-500 mb-2 err leading-6">
												{errors.email.message}
											</p>
										)}

										{errors.email && errors.email.type === 'required' && (
											<p className="h-6 text-left text-red-500 mb-2 err leading-6">
												{t('contact:emailRequiredErro')}
											</p>
										)}
										<input
											type="text"
											placeholder={t('contact:subjectPlaceholder')}
											className="sm:w-full xs:w-2/3 w-full mb-2 form_placeholder text-center"
											{...register('subject', { required: true })}
										/>
										{errors.subject && errors.subject.type === 'required' && (
											<p className="h-6 text-left text-red-500 mb-2 err leading-6">
												{t('contact:subjectError')}
											</p>
										)}

										<textarea
											placeholder={t('contact:messagePlaceholder')}
											className=" mb-2 form_placeholder text-center message-area mt-4 p-2"
											style={{ resize: 'none' }}
											{...register('message', { required: true })}
										/>
										{errors.message && errors.message.type === 'required' && (
											<p className="h-6 text-left text-red-500 mb-2 err leading-6">
												{t('contact:messageError')}
											</p>
										)}

										<button
											className="email_button flex justify-center space-x-5 cursor-pointer text-base px-3 py-1.5 bg-d-red text-white font-medium sm:w-full xs:w-2/3 w-full"
											disabled={disabled}
										>
											<img src={emailPhoto.src} className="emailText" />
											<p className="text-center emailText">
												{t('contact:button')}
											</p>
										</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</motion.div>
		</Layout>
	);
}