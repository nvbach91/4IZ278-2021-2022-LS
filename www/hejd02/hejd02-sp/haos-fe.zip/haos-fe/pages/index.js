import React from 'react';
import useTranslation from 'next-translate/useTranslation';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from '../components/Animations';

// components
import Layout from '../components/layout';
import BeltComponent from '../components/BeltComponent';
import LoginMessage from '../components/loginMessage';

import { useMainContext } from '../context/mainContext.js';

export default function Home() {
	const { products } = useMainContext();
	const { data } = useMainContext();
	let { t } = useTranslation();
	return (
		<Layout
			title={t('SEO:index.title')}
			metaDescription={t('SEO:index.description')}
			robots={true}
			pageType={'website'}
		>
			<motion.div
				variants={pageAnimation}
				initial="hidden"
				animate="enter"
				exit="exit"
				transition={{ type: 'linear' }}
				className="hlavniStranka mainWrapper"
			>
				{typeof window !== 'undefined' &&
					sessionStorage.getItem('loggedAnim') && <LoginMessage />}
				<div className="mainContainer main_content grid grid-cols-2 md:gap-4 gap-16 mb-8 justify-center md:mt-12 mt-0">
					{data &&
						data.map(item => {
							const {
								id,
								name,
								unBeltName,
								description,
								image,
								image2,
								altTag,
								text,
								link,
							} = item;
							return (
								<BeltComponent
									key={id}
									id={id}
									name={name}
									unBeltName={unBeltName}
									description={description}
									image={image}
									image2={image2}
									altTag={altTag}
									text={text}
									link={link}
								/>
							);
						})}
				</div>
			</motion.div>
		</Layout>
	);
}