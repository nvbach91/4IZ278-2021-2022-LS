import React from 'react';
import useTranslation from 'next-translate/useTranslation';

// react light box
import { SRLWrapper } from 'simple-react-lightbox';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from '../components/Animations';

// components
import Layout from '../components/layout';

// images
import image1 from '/public/images/belt.png';

export default function About() {
	let { t } = useTranslation();
	const images = [
		{
			id: 1,
			image: image1.src,
			alt: 'belt',
		},
		{
			id: 2,
			image: image1.src,
			alt: 'belt',
		},
		{
			id: 3,
			image: image1.src,
			alt: 'belt',
		},
		{
			id: 4,
			image: image1.src,
			alt: 'belt',
		},
		{
			id: 5,
			image: image1.src,
			alt: 'belt',
		},
		{
			id: 6,
			image: image1.src,
			alt: 'belt',
		},
		{
			id: 7,
			image: image1.src,
			alt: 'belt',
		},
		{
			id: 8,
			image: image1.src,
			alt: 'belt',
		},
		{
			id: 9,
			image: image1.src,
			alt: 'belt',
		},
	];
	const options = {
		settings: {
			autoplaySpeed: 1500,
			transitionSpeed: 1200,
			disableKeyboardControls: true,
			disableWheelControls: true,
			disablePanzoom: true,
		},
		caption: {
			captionFontFamily: "'Poppins', sans-serif",
			captionFontWeight: '300',
		},
		progressBar: {
			height: 0,
			showProgressBar: false,
		},
		thumbnails: {
			showThumbnails: true,
		},
	};
	return (
		<Layout
			title={t('SEO:about.title')}
			metaDescription={t('SEO:about.description')}
			robots={true}
			pageType={'website'}
		>
			<motion.div
				variants={pageAnimation}
				initial="hidden"
				animate="enter"
				exit="exit"
				transition={{ type: 'linear' }}
				className="mainWrapper z-1 about"
			>
				<div className="mainContainer">
					<div className="about-wrapper">
						<div className="main_1 flex justify-center flex-col md:pb-5 pb-3">
							<h1 className="text-center main_title font-semibold">HaoS</h1>
							<h2 className="font-light tracking-wide second_title md:mb-16 mb-10">
								{t('about:heading')}
							</h2>
							<div className="justify-center text-center leading-8 tracking-wide text text1  md:mb-16">
								<h3 className="font-semibold">{t('about:title1')}</h3>
								<p>{t('about:text1')}</p>
							</div>
						</div>
						<div className="flex md:flex-row flex-col">
							<div className="justify-center text-center leading-8 tracking-wide text md:my-0 my-8">
								<h3 className="font-semibold">{t('about:title2')}</h3>
								<p>{t('about:text2')}</p>
							</div>
							<div className="justify-center text-center leading-8 tracking-wide text">
								<h3 className="font-semibold">{t('about:title3')}</h3>
								<p>{t('about:text3')}</p>
							</div>
						</div>
					</div>
				</div>
			</motion.div>
		</Layout>
	);
}