import React, { useEffect, useState, useRef } from 'react';
import { useMainContext } from '/context/mainContext.js';
import useTranslation from 'next-translate/useTranslation';
import { useRouter } from 'next/router';
import { ADDRESS } from '/constants/routes';
import axios from 'axios';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from '/components/Animations';
import gsap from 'gsap';

// components
import Layout from '/components/layout';
import DetailComponent from '/components/DetailComponent';
import CartNewItem from '../../components/cartNewItem';

export default function Detail() {
	const { setStep } = useMainContext();
	const { setItems } = useMainContext();
	const { setNewItem } = useMainContext();
	const { setSizeGuideActive } = useMainContext();
	const [currentBelt, setCurrentBelt] = useState([]);
	let { t } = useTranslation();
	const router = useRouter();
	const container = useRef();
	let tl = gsap.timeline();
	const [quantity, setQuantity] = useState(1);
	const [orderedSize, setOrderedSize] = useState('');
	const [color, setColor] = useState(t('detailComponent:black'));
	const [colorErr, setColorErr] = useState('');
	const [orderedSizeId, setOrderedSizeId] = useState('');
	const [cartHandlerErr, setCartHandlerErr] = useState('');

	useEffect(() => {
		axios
			.get(`${ADDRESS}/product-slug/${router.query.link}`)
			.then(response => {
				setCurrentBelt(response.data.data);
			})
			.catch(err => {
				router.push('/404');
			});
	}, []);

	// pridani do kosiku
	const cartHandler = () => {
		let allProducts = [];
		let size_id = '';
		if(orderedSize === undefined) {
			setOrderedSize(currentBelt.size[0].size_id);
		}

		currentBelt.size.map(item => {
			if (item.size_type === orderedSize) {
				size_id = item.size_id;
				return true;
			}
		}),
		setCartHandlerErr('');
		let product = {
			product_id: currentBelt.product_id,
			title: currentBelt.attributes.product_name,
			quantity: quantity,
			price: currentBelt.attributes.price,
			size: orderedSize,
			product_size_id: size_id,
			// color: color
		};

		allProducts.push(product);
		let duplicity = false;

		currentBelt.size.map((item, index) => {
			if (item.size_type === orderedSize) {
				if (
					Number(currentBelt.size[index].pivot.remaining_quantity) <
					Number(quantity)
				) {
					return setCartHandlerErr(
						`${t('detailComponent:cartHandlerErr1')} ${
							currentBelt.size[index].pivot.remaining_quantity
						} ${t('detailComponent:cartHandlerErr2')}`,
					);
				} else {
					if (sessionStorage.getItem('products') === null) {
						tl.to(container.current, {
							display: 'block',
							duration: 0.1,
						});
						tl.to(container.current, {
							opacity: 1,
							duration: 0.2,
							onComplete: function () {
								setTimeout(() => {
									hideTheBox();
								}, 8000);
							},
						});
						sessionStorage.setItem('products', JSON.stringify(allProducts));
						sessionStorage.setItem('step', 1);
						setItems(JSON.parse(sessionStorage.getItem('products')).length);
						setNewItem(allProducts);
						sessionStorage.setItem('newProducts', JSON.stringify(allProducts));
					} else {
						let actual = JSON.parse(sessionStorage.getItem('products'));
						for (let i = 0; i < actual.length; i++) {
							if (
								actual[i].title === currentBelt.attributes.product_name &&
								actual[i].price === currentBelt.attributes.price &&
								actual[i].size === orderedSize
							) {
								if (
									Number(currentBelt.size[index].pivot.remaining_quantity) <
									Number(actual[i].quantity) + Number(quantity)
								) {
									return setCartHandlerErr(
										`${t('detailComponent:cartHandlerErr1')} ${
											currentBelt.size[index].pivot.remaining_quantity
										} ${t('detailComponent:cartHandlerErr2')}`,
									);
								} else {
									actual[i].quantity =
										Number(actual[i].quantity) + Number(quantity);
									duplicity = true;
									tl.to(container.current, {
										display: 'block',
										duration: 0.1,
									});
									tl.to(container.current, {
										opacity: 1,
										duration: 0.2,
										onComplete: function () {
											setTimeout(() => {
												hideTheBox();
											}, 8000);
										},
									});
								}
							}
						}
						if (!duplicity) {
							setItems(actual.length + 1);
							actual.push(product);
							tl.to(container.current, {
								display: 'block',
								duration: 0.1,
							});
							tl.to(container.current, {
								opacity: 1,
								duration: 0.2,
								onComplete: function () {
									setTimeout(() => {
										hideTheBox();
									}, 8000);
								},
							});
						}
						setNewItem(product);
						setStep('');
						sessionStorage.setItem('newProducts', JSON.stringify(product));
						sessionStorage.setItem('step', '');
						return sessionStorage.setItem('products', JSON.stringify(actual));
					}
					sessionStorage.removeItem('fourth');
				}
			}
		});
	};

	const hideTheBox = link => {
		tl.to(container.current, {
			opacity: 0,
			onComplete: function () {
				if (link) {
					router.push(link);
				}
			},
		});
		tl.to(container.current, {
			display: 'none',
			onComplete: function () {
				setNewItem([]);
				sessionStorage.removeItem('newProducts');
			},
		});
	};
	return (
		<Layout
			title={
				currentBelt.attributes && currentBelt.attributes.product_name
					? currentBelt.attributes.product_name
					: ''
			}
			metaDescription={
				router.query.link.toLowerCase().includes('bitcoin')
					? t('SEO:products1.description')
					: t('SEO:products2.description')
			}
			robots={true}
			pageType={'website'}
		>
			<motion.div
				variants={pageAnimation}
				initial="hidden"
				animate="enter"
				exit="exit"
				transition={{ type: 'linear' }}
				className="mainWrapper z-1 detail"
			>
				<CartNewItem hideTheBox={hideTheBox} container={container} />
				{currentBelt && currentBelt.attributes && (
					<DetailComponent
						name={currentBelt.attributes.product_name}
						unBeltName={currentBelt.attributes.product_name}
						description={currentBelt.attributes.description}
						price={currentBelt.attributes.price}
						// images={currentBelt.images}
						cartHandler={cartHandler}
						container={container}
						quantity={quantity}
						setQuantity={setQuantity}
						orderedSize={orderedSize}
						setOrderedSize={setOrderedSize}
						sizes={currentBelt.size}
						cartHandlerErr={cartHandlerErr}
						setSizeGuideActive={setSizeGuideActive}
						color={color}
						setColor={setColor}
						colorErr={colorErr}
						setColorErr={setColorErr}
					/>
				)}
			</motion.div>
		</Layout>
	);
}
