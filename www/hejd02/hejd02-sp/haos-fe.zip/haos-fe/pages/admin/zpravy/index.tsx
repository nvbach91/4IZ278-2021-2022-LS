// react hooks
import React, { useEffect, useState } from 'react';
import useTranslation from 'next-translate/useTranslation';
import * as ROUTES from '../../../constants/routes';

// interfaces, routes
import IPage from '../../../interfaces/page';
import { ADDRESS } from '../../../constants/routes';
import { useRouter } from 'next/router';

// components
import AdministrationTable from '../../../components/adminTable';
import Sidebar from '../../../components/adminSidebar';
import SidebarButton from '../../../components/SidebarButton';
import Layout from '../../../components/layout';
import Loading from '../../../components/loading';
import NoData from '../../../components/noData';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from '../../../components/Animations';
import axios from 'axios';

const AdminMessages: React.FunctionComponent<IPage> = () => {
	let { t } = useTranslation();
	const [messages, setMessages] = useState([]);
	const [loaded, setLoaded] = useState(false);
	const colgroup = [5, 15, 20, 30, 15, 15];
	const router = useRouter();
	const thead = [
		'ID',
		`${t('adminMessages:thead2')}`,
		'Email',
		`${t('adminMessages:thead4')}`,
		`${t('adminMessages:thead5')}`,
		`${t('adminMessages:thead6')}`,
	];
	const wantedParams = ['id', 'attributes', 'email', 'subject'];
	const buttons = [
		{ name: `${t('adminMessages:thead5')}`, type: 'unpack', table: '', key: '', url: '' },
		{
			name: `${t('adminMessages:thead6')}`,
			type: 'delete',
			table: 'message',
			key: 'id',
			url: '',
		},
	];
	const additionalContent = ['name', 'message'];
	const additionalContentTXT = [
		`${t('adminMessages:additional1')}`,
		`${t('adminMessages:additional2')}`,
	];
	const [changeData, setChangeData] = useState(false);
	const [params, setParams] = useState({});
	const [user, setUser] = useState('');
	const [update, updateState] = React.useState(0);
	const forceUpdate = () => {
		updateState(update + 1);
	};
	const [activeSideBar, setActiveSideBar] = useState(Boolean);
	function HandleChange() {
		if (!changeData) {
			setParams([
				{
					column: 'email_to',
					value: null,
				},
			]);
			setChangeData(true);
		} else if (changeData) {
			setParams([]);
			setChangeData(false);
		}
	}
	const getData = async () => {
		if (user === "prihlasen") {
			axios
				.get(`${ADDRESS}/admin/message`, {
					headers: {
						Authorization: 'Bearer ' + localStorage.getItem('token'),
					},
				})
				.then(res => {
					setMessages(res.data.data);
				});
		}
	};
	useEffect(() => {
		getData();
	}, [user, update]);

	useEffect(() => {
		if (user === "neprihlasen") {
			router.push(ROUTES.LOGIN);
		}
	}, [user]);
	
	useEffect(() => {
		if (messages) {
			setLoaded(true);
		}
		if (
			!window.localStorage.getItem('logged') ||
			!window.localStorage.getItem('token')
		) {
			setUser('neprihlasen');
		} else {
			setUser('prihlasen');
		}
	}, [user]);

	if (user == 'neprihlasen') {
		return <div />;
	}

	return (
		<Layout
			title={t('SEO:adminMessages.title')}
			metaDescription={t('SEO:adminMessages.description')}
			robots={false}
			pageType={'website'}
		>
			<motion.div
				className={'adminContainer'}
				variants={pageAnimation}
				initial="hidden"
				animate="enter"
				exit="exit"
				transition={{ type: 'linear' }}
			>
				<div className={'addedControlls'}>
					<SidebarButton
						setActiveSideBar={setActiveSideBar}
						activeSideBar={activeSideBar}
					/>
				</div>
				<div className="flex-menu flex-col">
					<div className="w-full text-right text-white pageTitle py-3 pr-9 mb-5 flex gap-x-5 items-center justify-end">
						<span>{t('adminMessages:title')}</span>
					</div>
					<Sidebar activeSideBar={activeSideBar} />
				</div>
				<div className={'tableWrapper messagesWrapper'}>
					{loaded ? (
						messages.length > 0 ? (
							<AdministrationTable
								colgroup={colgroup}
								thead={thead}
								tbody={messages}
								wantedParams={wantedParams}
								buttons={buttons}
								type={'addedRow'}
								additionalContent={additionalContent}
								additionalContentTXT={additionalContentTXT}
								// @ts-ignore
								update={forceUpdate}
								table={'messages'}
							/>
						) : (
							<NoData messagesErr={true} />
						)
					) : (
						<Loading />
					)}
				</div>
			</motion.div>
		</Layout>
	);
};

export default AdminMessages;