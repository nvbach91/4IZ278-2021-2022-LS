// react hooks
import React, { useState, useEffect } from 'react';
import useTranslation from 'next-translate/useTranslation';
import * as ROUTES from '../../../constants/routes';

// interfaces, routes
import IPage from '../../../interfaces/page';
import { ADDRESS } from '../../../constants/routes';
import { useRouter } from 'next/router';

// components
import AdministrationTable from '../../../components/adminTable';
import Sidebar from '../../../components/adminSidebar';
import SidebarButton from '../../../components/SidebarButton';
import Layout from '../../../components/layout';
import Loading from '../../../components/loading';
import NoData from '../../../components/noData';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from '../../../components/Animations';
import axios from 'axios';

const Orders: React.FunctionComponent<IPage> = () => {
	let { t } = useTranslation();
	const [loaded, setLoaded] = useState(false);
	const router = useRouter();
	const colgroup = [5, 15, 20, 15, 15, 15];
	const thead = [
		'ID',
		`${t('adminOrders:thead2')}`,
		`${t('adminOrders:thead4')}`,
		`${t('adminOrders:thead5')}`,
		`${t('adminOrders:thead6')}`,
		`${t('adminOrders:thead7')}`,
		`${t('adminOrders:invoice')}`,
	];
	const wantedParams = ['order_id', 'user', 'products', 'status', 'attributes'];
	const [items, setItems] = useState([]);
	const [user, setUser] = useState('');
	const buttons = [
		{
			name: `${t('adminOrders:thead6')}`,
			type: 'unpack',
			table: '',
			key: '',
			url: '',
		},
		{
			name: `${t('adminOrders:thead7')}`,
			type: 'delete',
			table: 'order',
			key: 'id',
			url: '',
		},
		{
			name: `${t('adminOrders:invoice')}`,
			type: 'invoice',
			table: 'order',
			key: 'id',
			url: '',
		},
	];
	const additionalContent = [
		'user_name',
		'user_phone',
		'user_email',
		'note',
		'products',
		'address',
	];
	const additionalContentTXT = [
		`${t('adminOrders:additional1')}: `,
		`${t('adminOrders:additional2')}: `,
		`${t('adminOrders:additional3')}: `,
		`${t('adminOrders:additional4')}: `,
		`${t('adminOrders:additional5')}: `,
		`${t('adminOrders:additional6')}: `,
	];
	const [activeSideBar, setActiveSideBar] = useState(Boolean);
	const [update, updateState] = React.useState(0);
	const forceUpdate = () => {
		updateState(update + 1);
	};

	useEffect(() => {
		if (user === "prihlasen") {
			axios
				.get(`${ADDRESS}/admin/order`, {
					headers: {
						Authorization: 'Bearer ' + localStorage.getItem('token'),
					},
				})
				.then(res => {
					setItems(res.data.data);
				});
		}
	}, [update, user]);

	useEffect(() => {
		if (user === 'neprihlasen') {
			router.push(ROUTES.LOGIN);
		}
	}, [user]);

	useEffect(() => {
		if (items) {
			setLoaded(true);
		}
		if (
			!window.localStorage.getItem('logged') ||
			!window.localStorage.getItem('token')
		) {
			setUser('neprihlasen');
		} else {
			setUser('prihlasen');
		}
	}, [user]);

	if (user == 'neprihlasen') {
		return <div />;
	}

	return (
		<Layout
			title={t('SEO:adminOders.title')}
			metaDescription={t('SEO:adminOders.description')}
			robots={false}
			pageType={'website'}
		>
			<motion.div
				className={'adminContainer'}
				variants={pageAnimation}
				exit="exit"
				initial="hidden"
				animate="show"
			>
				<div className={'addedControlls'}>
					<SidebarButton
						setActiveSideBar={setActiveSideBar}
						activeSideBar={activeSideBar}
					/>
				</div>
				<div className="flex-menu flex-col">
					<div className="w-full text-right text-white pageTitle  pr-9 mb-5 flex gap-x-5 items-center justify-end py-3">
						<span>{t('adminOrders:title')}</span>
					</div>
					<Sidebar activeSideBar={activeSideBar} />
				</div>
				<div className={'tableWrapper'}>
					{loaded ? (
						items.length > 0 ? (
							<AdministrationTable
								colgroup={colgroup}
								thead={thead}
								tbody={items}
								wantedParams={wantedParams}
								buttons={buttons}
								type={'addedRow'}
								additionalContent={additionalContent}
								additionalContentTXT={additionalContentTXT}
								//@ts-ignore
								update={forceUpdate}
								table={'order'}
								updateState={updateState}
							/>
						) : (
							<NoData ordersErr={true} />
						)
					) : (
						<Loading />
					)}
				</div>
			</motion.div>
		</Layout>
	);
};

export default Orders;
