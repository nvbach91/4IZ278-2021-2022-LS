// react hooks
import React, { useEffect, useRef, useState } from 'react';
import useTranslation from 'next-translate/useTranslation';
import Link from 'next/link';
import { Editor } from '@tinymce/tinymce-react';
import { useForm } from 'react-hook-form';
import Router, { useRouter } from 'next/router';

// routes, interfaces
import IPage from '../../../../interfaces/page';
import { ADDRESS } from '../../../../constants/routes';
import * as ROUTES from '../../../../constants/routes';

// axios, fetch
import axios from 'axios';

// components
import SidebarButton from '../../../../components/SidebarButton';
import Sidebar from '../../../../components/adminSidebar';
import Layout from '../../../../components/layout';
import Loading from '../../../../components/loading';

// images
import icon from '../../../../public/images/admin-products-icon.png';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from '../../../../components/Animations';

const AdminBlogAdd: React.FunctionComponent<IPage> = () => {
	let { t } = useTranslation();
	const [loaded, setLoaded] = useState(false);
	const router = useRouter();
	const { id } = router.query;
	const editorRef = useRef<any>();
	const [welcomePhoto, setWelcomePhoto] = useState('');
	const [selectedFile, setSelectedFile] = useState();
	const [isFilePicked, setIsFilePicked] = useState(false);
	const [productName, setProductName] = useState('');
	const [categoryChoice, setCategoryChoice] = useState('');
	const [productNameErr, setProductNameErr] = useState('');
	const [categoryErr, setCategoryErr] = useState('');
	const [fileErr, setFileErr] = useState('');
	const [productErr, setProductErr] = useState('');
	const [productSuccErr, setProductSuccErr] = useState('');
	const [categories, setCategories] = useState([]);
	const [disabled, setDisabled] = useState(false);
	const [image, setImage] = useState();
	const [color, setColor] = useState('');
	const [colorErr, setColorErr] = useState('');
	const [sizes, setSizes] = useState([]);
	const [amountInStockErr, setAmountInStockErr] = useState('');
	const [amountInStock, setAmountInStock] = useState('');
	const [currentProduct, setCurrentProduct] = useState([]);
	const [editor, setEditor] = useState(false);
	const [textErr, setTextErr] = useState('');
	const [text, setText] = useState('');
	const [sizeErr, setSizeErr] = useState('');
	const [currentSizes, setCurrentSizes] = useState([]);
	const [newCategory, setNewCategory] = useState('');
	const [newCategoryErr, setNewCategoryErr] = useState('');
	const [disabled2, setDisabled2] = useState(false);
	const [disabled3, setDisabled3] = useState(false);
	const [errorMsg, setErrorMsg] = useState('');
	const [succMsg, setSuccMsg] = useState('');
	const [currentSize, setCurrentSize] = useState('');
	const [currentSizeErr, setCurrentSizeErr] = useState('');
	const [allSizes, setAllSizes] = useState([]);
	const [price, setPrice] = useState('');
	const [priceErr, setPriceErr] = useState('');
	const [slug, setSlug] = useState('');
	const [slugErr, setSlugErr] = useState('');
	const {
		register,
		handleSubmit,
		formState: { errors },
		reset,
		setValue,
		getValues,
	} = useForm();
	const [user, setUser] = useState('');

	useEffect(() => {
		if (user === 'neprihlasen') {
			router.push(ROUTES.LOGIN);
		}
	}, [user]);

	useEffect(() => {
		if (currentProduct) {
			setLoaded(true);
		}
		if (
			!window.localStorage.getItem('logged') ||
			!window.localStorage.getItem('token')
		) {
			setUser('neprihlasen');
		}
		setEditor(true);
	}, []);

	const addCategory = async (e: any) => {
		e.preventDefault();
		setDisabled2(true);
		if (newCategory.length !== 0 && disabled2 !== true) {
			const formData = new FormData();
			formData.append('name', newCategory);
			await fetch(`${ADDRESS}/admin/category`, {
				credentials: 'include',
				headers: {
					Authorization: 'Bearer ' + localStorage.getItem('token'),
				},
				method: 'POST',
				body: formData,
			})
				.catch(err => {
					if (err) {
						setErrorMsg(`${t('adminProducts:errMsg')}`);
						setDisabled2(false);
					}
				})
				.then(response => {
					setErrorMsg('');
					setNewCategory('');
					setDisabled2(false);
					setSuccMsg(`${t('adminProducts:succMsg')}`);
				});
			setTimeout(() => {
				setSuccMsg('');
			}, 3000);
			fetchCategories();
		} else {
			setNewCategoryErr(`${t('adminProducts:newCatErr')}`);
			setDisabled2(false);
		}
	};
	const deleteCategory: any = (id: string) => {
		setDisabled3(true);
		//@ts-ignore
		axios
			.delete(`${ADDRESS}/admin/category/${id}`, {
				headers: {
					Authorization: 'Bearer ' + localStorage.getItem('token'),
				},
			})
			.then(response => {
				setDisabled3(false);
				let basicChild = document.getElementById('basicChild' + id);
				fetchCategories();
				if (basicChild) {
					basicChild.style.display = 'none';
				}
			});
	};
	const fetchCategories = async () => {
		axios.get(`${ADDRESS}/category`).then(res => {
			setCategories(res.data.data);
		});
	};

	useEffect(() => {
		if (id) {
			axios.get(`${ADDRESS}/product/${id}`).then(res => {
				setCurrentProduct(res.data.data);
			});
		}
	}, [id]);

	useEffect(() => {
		axios.get(`${ADDRESS}/category`).then(res => {
			setCategories(res.data.data);
		});
		axios.get(`${ADDRESS}/size`).then(res => {
			setSizes(res.data.data);
		});
	}, []);

	useEffect(() => {
		//@ts-ignore
		if (
			currentProduct &&
			//@ts-ignore
			currentProduct.attributes &&
			//@ts-ignore
			currentProduct.category
		) {
			//@ts-ignore
			setAllSizes(currentProduct.size);
			//@ts-ignore
			setProductName(currentProduct.attributes.product_name);
			//@ts-ignore
			setSlug(currentProduct.slug);
			//@ts-ignore
			setColor(currentProduct.attributes.color);
			//@ts-ignore
			setCategoryChoice(currentProduct.category.name);
			//@ts-ignore
			setText(currentProduct.attributes.description);
			//@ts-ignore
			setPrice(currentProduct.attributes.price);
			//@ts-ignore
			setCategoryChoice(currentProduct.category.category_id);
		}
	}, [currentProduct]);

	if (getValues('size') && sizes) {
		getValues('size').forEach(element => {
			if (currentSizes.indexOf(element.size_id) === -1) {
				setCurrentSizes(currentSizes => [...currentSizes, element.size_id]);
			}
		});
	}

	const addSize = e => {
		e.preventDefault();
		if (currentSize !== '' && amountInStock !== '') {
			setCurrentSizeErr('');
			setAmountInStockErr('');
			if (
				allSizes.filter(item => Number(item.size_id) === Number(currentSize))
					.length === 0
			) {
				setAllSizes([
					...allSizes,
					{
						id: allSizes.length,
						size_id: currentSize,
						remaining_quantity: amountInStock,
					},
				]);
				setCurrentSize('');
				setAmountInStock('');
			} else {
				setCurrentSizeErr(`${t('adminProducts:currentSizeErr2')}`);
			}
		} else {
			if (currentSize === '') {
				setCurrentSizeErr(`${t('adminProducts:currentSizeErr')}`);
			}
			if (amountInStockErr === '') {
				setAmountInStockErr(`${t('adminProducts:amountErr')}`);
			}
		}
	};

	const delSize = (e, index) => {
		e.preventDefault();
		let newarray = allSizes.filter(element =>
			element.size_id ? element.size_id !== index : element.id !== index,
		);
		setAllSizes(newarray);
	};

	// const changeHandler = (event: {
	// 	target: { files: React.SetStateAction<undefined>[] };
	// }) => {
	// 	setIsFilePicked(true);
	// 	if (event.target.files[0]) {
	// 		setSelectedFile(event.target.files[0]);
	// 		setWelcomePhoto(event.target.files[0].name);
	// 		//@ts-ignore
	// 		setImage(URL.createObjectURL(event.target.files[0]));
	// 	}
	// };

	const log = async (e: any) => {
		e.preventDefault();
		setProductNameErr('');
		setCategoryErr('');
		setFileErr('');
		setProductNameErr('');
		setSlugErr('');
		setColorErr('');
		setColorErr('');
		setPriceErr('');
		setSizeErr('');
		setTextErr('');
		if (editorRef.current) {
			let sizeArray = [];
			allSizes.map(item => {
				sizeArray.push(item.size_id);
			});
			const productObj = {
				product_name: productName,
				slug: slug,
				price: price,
				color: color,
				category_id: categoryChoice,
				description: editorRef.current.getContent(),
				//sizes: sizeArray,
			};
			if (productName === '') {
				setProductNameErr(`${t('adminProducts:productNameError')}`);
			}
			if (slug === '') {
				setSlugErr(`${t('adminProducts:slugErr')}`);
			}
			if (color === '') {
				setColorErr(`${t('adminProducts:colorError')}`);
			}
			if (
				productObj.category_id === '' ||
				productObj.category_id === `${t('adminProducts:chooseTheCategory')}`
			) {
				setCategoryErr(`${t('adminProducts:categoryError')}`);
			}
			// if (welcomePhoto === '') {
			// 	setFileErr('Image is required!');
			// }
			if (productObj.description === '') {
				setTextErr(`${t('adminProducts:descriptionError')}`);
			}
			// if (productObj.sizes.length === 0) {
			// 	setSizeErr(`${t('adminProducts:sizesError')}`);
			// }
			if (!productObj.price) {
				setPriceErr(`${t('adminProducts:priceError')}`);
			}

			if (
				Object.values(productObj).filter(
					item =>
						item === '' || item === `${t('adminProducts:chooseTheCategory')}`,
				).length === 0
			) {
				setDisabled(true);
				await axios
					.put(`${ADDRESS}/admin/product/${id}`, productObj, {
						headers: {
							Authorization: 'Bearer ' + localStorage.getItem('token'),
						},
					})
					.catch(err => {
						if (err) {
							setProductErr(`${t('adminProducts:productErrorEdit')}`);
							setDisabled(false);
						}
					})
					.then(response => {
						if (response) {
							setDisabled(false);
							setProductSuccErr(`${t('adminProducts:productSuccErrorEdit')}`);
							Router.push('/admin/produkty');
						}
					});
				setProductName('');
				setCategoryChoice('');
				setWelcomePhoto('');
				editorRef.current.setContent('');
				// @ts-ignore
				setImage();
				setTimeout(() => {
					setProductErr('');
					setProductSuccErr('');
				}, 3000);
			}
		}
	};

	const [activeSideBar, setActiveSideBar] = useState(Boolean);
	if (user == 'neprihlasen') {
		return <div />;
	}
	return (
		<Layout
			title={t('SEO:adminProducts.title')}
			metaDescription={t('SEO:adminProducts.description')}
			robots={false}
			pageType={'website'}
		>
			<motion.div
				className={'adminContainer blog'}
				variants={pageAnimation}
				exit="exit"
				initial="hidden"
				animate="show"
			>
				{disabled ? <Loading /> : null}
				<div className={'addedControlls'}>
					<SidebarButton
						setActiveSideBar={setActiveSideBar}
						activeSideBar={activeSideBar}
					/>
					<div className="button-container">
						<Link href={`${ROUTES.ADMIN_PRODUCTS}`}>
							<a id={'adminHelperBtn'} className={'adminHelperBtn'}>
								{t('adminProducts:button')}
							</a>
						</Link>
					</div>
				</div>
				<Sidebar activeSideBar={activeSideBar} />
				<div className={'addedRowForm blogAdd py-4 px-3'}>
					<div className={'rowForm blogRow w-full'}>
						<form className={'addCategory'}>
							<div className={'rowForm addCategoryCol'}>
								<input
									className={'basicInput adminInput mb-4 input'}
									type={'text'}
									placeholder={`${t('adminProducts:catPlaceholder')}`}
									value={newCategory}
									onChange={evt => {
										setNewCategory(evt.target.value);
									}}
								/>
								<span className={'error'}>{newCategoryErr}</span>
							</div>
							<div className={'rowForm addCategoryCol'}>
								<button
									className={'adminSentBtn'}
									onClick={e => {
										setDisabled2(true);
										addCategory(e);
									}}
								>
									{t('adminProducts:addCat')}
								</button>
							</div>
						</form>
						{succMsg !== '' ? <p className="succAlert">{succMsg}</p> : null}
						{errorMsg !== '' ? <p className="errorAlert">{errorMsg}</p> : null}
					</div>
					<div className={'rowForm blogRow catRow p-0 m-0'}>
						{categories
							? categories
									//@ts-ignore
									// .map(item => item.category_name)
									// .filter((value, index, self) => self.indexOf(value) === index)
									.map(item => {
										const { category_id, name } = item;
										return (
											<div className="catDis w-1/4 my-1" key={category_id}>
												<div className="borders mx-1 h-full text-white flex items-center justify-between">
													<div className="w-full">
														<p className="py-5 px-4 font-semibold uppercase">
															{name}
														</p>
													</div>
													<button
														className="button flex flex-col items-center justify-center cursor-pointer"
														onClick={() => deleteCategory(category_id)}
														disabled={disabled3}
													>
														<span className="w-6 block bg-white" />
														<span className="w-6 block bg-white" />
													</button>
												</div>
											</div>
										);
									})
							: null}
					</div>
					<div className={'rowForm editor'}>
						<form method="post">
							<div className={'rowForm'}>
								<input
									className={'basicInput adminInput input p-2'}
									type={'text'}
									placeholder={`${t('adminProducts:productNamePlaceholder')}`}
									onChange={evt => setProductName(evt.target.value)}
									value={productName}
								/>
								<div className="my-2">
									{productNameErr ? (
										<label className={'error leading-7 p-0 m-0'}>
											{productNameErr}
										</label>
									) : null}
								</div>
								<input
									className={'basicInput adminInput input p-2'}
									type={'text'}
									placeholder={`Slug`}
									onChange={evt => setSlug(evt.target.value)}
									value={slug}
								/>
								<div className="my-2">
									{slugErr ? (
										<label className={'error leading-7 p-0 m-0'}>
											{slugErr}
										</label>
									) : null}
								</div>
								<select
									className={'basicInput adminInput input p-2'}
									onChange={evt => setCategoryChoice(evt.target.value)}
									value={categoryChoice}
								>
									<option key="0">
										{t('adminProducts:chooseTheCategory')}
									</option>
									{categories
										? categories
												//@ts-ignore
												.map(item => {
													const { category_id, name } = item;
													return (
														<option key={category_id} value={category_id}>
															{name}
														</option>
													);
												})
										: null}
								</select>
								<div className="my-2">
									{categoryErr ? (
										<label className={'error leading-7 p-0 m-0'}>
											{categoryErr}
										</label>
									) : null}
								</div>
								<div className="categories-container p-5">
									<div className="flex gap-5 flex-row justify-center items-center">
										<div className="w-full">
											<select
												className={'basicInput adminInput input h-full'}
												onChange={evt => setCurrentSize(evt.target.value)}
												value={currentSize}
											>
												<option key="0">
													{t('adminProducts:selectTheSizes')}
												</option>
												{sizes
													? sizes
															//@ts-ignore
															.map(item => {
																const { size_type, size_id } = item;
																return (
																	<option key={size_id} value={size_id}>
																		{size_type}
																	</option>
																);
															})
													: null}
											</select>
											<div className="my-2 h-6">
												{currentSizeErr !== '' ? (
													<p className={'error leading-7 p-0 m-0'}>
														{currentSizeErr}
													</p>
												) : null}
											</div>
										</div>
										<div className="w-full h-full">
											<input
												type="number"
												min={0}
												placeholder={t(
													'adminProducts:amountInStockPlaceholder',
												)}
												onChange={evt => setAmountInStock(evt.target.value)}
												value={amountInStock}
												className={'basicInput adminInput input p-2'}
											/>
											<div className="my-2 h-5">
												{amountInStockErr !== '' ? (
													<p className={'error leading-7 p-0 m-0'}>
														{amountInStockErr}
													</p>
												) : null}
											</div>
										</div>
									</div>
									<div className="flex justify-center">
										<button
											className="btn-size mt-3"
											onClick={e => {
												addSize(e);
											}}
										>
											{t('adminProducts:addBtn')}
										</button>
									</div>
									<div className="grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1 gap-4">
										{allSizes.map((size, index) => {
											const { id, size_id, remaining_quantity } = size;
											return (
												<div
													key={index}
													className="p-4 flex-1 w-full md:ml-2 ml-0 mt-3 rounded-lg border-2 border-gray-600 border-opacity-100"
												>
													<h5 className="text-lg font-semibold">
														{t('adminProducts:size')}: {size_id}
													</h5>
													<p>
														{t('adminProducts:amount')}:{' '}
														{remaining_quantity
															? remaining_quantity
															: size.pivot.remaining_quantity}
													</p>
													<button
														className="btn-default transitions delete cursor-pointer block text-center bg-blue-300 mb-0 shadow-sm"
														onClick={e => delSize(e, size_id)}
														type="button"
													>
														{t('adminProducts:delete')}
													</button>
												</div>
											);
										})}
									</div>
								</div>
								<div className="my-2">
									{sizeErr ? (
										<label className={'error leading-7 p-0 m-0'}>
											{sizeErr}
										</label>
									) : null}
								</div>
								<input
									className={'basicInput adminInput input p-2'}
									type={'text'}
									placeholder={t('adminProducts:colorPlaceholder')}
									onChange={evt => setColor(evt.target.value)}
									value={color}
								/>
								<div className="my-2">
									{colorErr ? (
										<label className={'error leading-7 p-0 m-0'}>
											{colorErr}
										</label>
									) : null}
								</div>
								<div className="input-box" id="input-box-2">
									<input
										type="number"
										className={' basicInput adminInput input p-2'}
										placeholder={t('adminProducts:pricePlaceholder')}
										onChange={evt => setPrice(evt.target.value)}
										value={price}
									/>
									<div className="my-2">
										{priceErr ? (
											<label className={'error leading-7 p-0 m-0'}>
												{priceErr}
											</label>
										) : null}
									</div>
								</div>
								{/* <div className={'rowForm blogRow catRow p-0 m-0 mb-2'}>
									<span className="span-amount p-2">
										{t('adminProducts:amountInStockPlaceholder')}
									</span>
									<input
										type="number"
										min={0}
										value={amountInStock}
										placeholder={t('adminProducts:amountInStockPlaceholder')}
										className={'basicInput adminInput input p-2'}
										onChange={e => {
											//@ts-ignore
											setAmountInStock(e.target.value);
										}}
									/>
								</div> */}
								{/* <label className="z-1">
								<input
									type="file"
									className="hidden"
									// value={welcomePhoto}
									name="image"
									// @ts-ignore
									onChange={changeHandler}
									accept="image/x-png, image/png, image/jpg, image/jpeg, image/gif"
								/>
								<div className="input-file flex input-container h-full cursor-pointer basicInput adminInput fileInput items-center gap-x-4 ">
									<img src={icon.src} alt="icon" className="h-14" />
									{!image ? (
										<input
											type="text"
											readOnly
											className="outline-none fileInput z-10"
											placeholder="Choose the image"
										/>
									) : (
										<img src={image} alt="blog-image" className="w-36" />
									)}
								</div>
								<div className="my-2">
									{fileErr ? (
										<label className={'error leading-7 p-0 m-0'}>
											{fileErr}
										</label>
									) : null}
								</div>
							</label> */}
							</div>
							<div className={'rowForm'}>
								{editor ? (
									<Editor
										apiKey="a8zubyyl16d8v8m0k5jnlgm34byg8qg0hoelznpecrq9io2l"
										// @ts-ignore
										onInit={(evt, editor) => (editorRef.current = editor)}
										initialValue={text}
										init={{
											height: 800,
											menubar: 'insert',
											automatic_uploads: true,
											images_upload_credentials: true,
											plugins: [
												'advlist autolink lists link image charmap print preview anchor',
												'searchreplace visualblocks code fullscreen',
												'image',
												'insertdatetime media table paste code help wordcount',
											],
											toolbar:
												'undo redo | formatselect | ' +
												'bold italic backcolor | alignleft aligncenter ' +
												'alignright alignjustify | bullist numlist outdent indent | ' +
												'image' +
												'removeformat | help',
											content_style:
												'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }',
										}}
									/>
								) : null}
								<div className="my-2">
									{textErr ? (
										<label className={'error leading-7 p-0 m-0'}>
											{textErr}
										</label>
									) : null}
								</div>
							</div>
							{productErr !== '' ? (
								<p className="errorAlert">{productErr}</p>
							) : null}
							{productSuccErr !== '' ? (
								<p className="succAlert">{productSuccErr}</p>
							) : null}
							<div className="w-full text-center mt-5 mb-1">
								<button
									type="submit"
									disabled={disabled}
									className="btn-default mx-auto text-white btn-add px-6 py-1.5 font-semibold"
									onClick={e => {
										log(e);
									}}
								>
									{t('adminProducts:editBtn')}
								</button>
							</div>
						</form>
					</div>
				</div>
			</motion.div>
		</Layout>
	);
};

export default AdminBlogAdd;