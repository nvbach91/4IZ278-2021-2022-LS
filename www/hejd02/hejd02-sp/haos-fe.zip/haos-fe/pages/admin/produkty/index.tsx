// react hooks
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import useTranslation from 'next-translate/useTranslation';
import * as ROUTES from '../../../constants/routes';

// interfaces, routes
import IPage from '../../../interfaces/page';
import { ADDRESS } from '../../../constants/routes';
import { useRouter } from 'next/router';

// components
import AdministrationTable from '../../../components/adminTable';
import Sidebar from '../../../components/adminSidebar';
import SidebarButton from '../../../components/SidebarButton';
import icon from '../../../public/images/addIcon.png';
import Layout from '../../../components/layout';
import Loading from '../../../components/loading';
import NoData from '../../../components/noData';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from '../../../components/Animations';

const ProductsFunc: React.FunctionComponent<IPage> = () => {
	let { t } = useTranslation();
	const [loaded, setLoaded] = useState(false);
	const router = useRouter();
	const colgroup = [10, 25, 15, 15, 15, 10];
	const thead = [
		'ID',
		`${t('adminProducts:thead2')}`,
		`${t('adminProducts:thead3')}`,
		`${t('adminProducts:thead4')}`,
		`${t('adminProducts:thead5')}`,
		`${t('adminProducts:thead6')}`,
		`${t('adminProducts:thead7')}`,
	];
	const wantedParams = [
		'product_id',
		'product_name',
		'price',
		'color',
		'category',
	];
	const [items, setItems] = useState([]);
	const [user, setUser] = useState('');
	const buttons = [
		{
			name: `${t('adminProducts:thead6')}`,
			type: 'edit',
			table: '',
			key: '',
			url: 'produkty/edit/',
		},
		{
			name: `${t('adminProducts:thead7')}`,
			type: 'delete',
			table: 'product',
			key: 'id',
			url: '',
		},
	];
	const [activeSideBar, setActiveSideBar] = useState(Boolean);
	const [update, updateState] = React.useState(0);
	const forceUpdate = () => {
		updateState(update + 1);
	};

	// @ts-ignore
	useEffect(async () => {
		if (user === "prihlasen") {
			const res = await fetch(`${ADDRESS}/product`, {
				headers: {
					Authorization: 'Bearer ' + localStorage.getItem('token'),
				},
			})
			const items = await res.json();
			setItems(items.data);
		}
	}, [user, update]);

	useEffect(() => {
		items.map(item => {
			console.log(item.size);
		})
	}, [])

	useEffect(() => {
		if (user === 'neprihlasen') {
			router.push(ROUTES.LOGIN);
		}
	}, [user]);

	useEffect(() => {
		if (items) {
			setLoaded(true);
		}
		if (
			!window.localStorage.getItem('logged') ||
			!window.localStorage.getItem('token')
		) {
			setUser('neprihlasen');
		} else {
			setUser('prihlasen');
		}
	}, [user]);

	if (user == "neprihlasen") {
		return <div />;
	}

	return (
		<Layout
			title={t('SEO:adminProducts.title')}
			metaDescription={t('SEO:adminProducts.description')}
			robots={false}
			pageType={'website'}
		>
			<motion.div
				className={'adminContainer'}
				variants={pageAnimation}
				exit="exit"
				initial="hidden"
				animate="show"
			>
				<div className={'addedControlls'}>
					<SidebarButton
						setActiveSideBar={setActiveSideBar}
						activeSideBar={activeSideBar}
					/>
				</div>
				<div className="flex-menu flex-col">
					<div className="w-full text-right text-white pageTitle  pr-9 mb-5 flex gap-x-5 items-center justify-end py-3">
						<span>{t('adminProducts:title')}</span>
						<Link href="/admin/produkty/add">
							<a>
								<img src={icon.src} alt="add" className="w-8 cursor-pointer" />
							</a>
						</Link>
					</div>
					<Sidebar activeSideBar={activeSideBar} />
				</div>
				<div className={'tableWrapper'}>
					{loaded ? (
						items.length > 0 ? (
							<AdministrationTable
								colgroup={colgroup}
								thead={thead}
								tbody={items}
								wantedParams={wantedParams}
								buttons={buttons}
								type={'addedRow'}
								additionalContent={null}
								additionalContentTXT={null}
								//@ts-ignore
								update={forceUpdate}
								table={'products'}
							/>
						) : (
							<NoData ordersErr={true} />
						)
					) : (
						<Loading />
					)}
				</div>
			</motion.div>
		</Layout>
	);
};

export default ProductsFunc;