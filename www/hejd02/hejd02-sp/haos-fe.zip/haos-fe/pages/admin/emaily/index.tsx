// react hooks
import React, { useState, useEffect } from 'react';
import useTranslation from 'next-translate/useTranslation';
import * as ROUTES from '../../../constants/routes';

// interfaces, routes
import IPage from '../../../interfaces/page';
import { ADDRESS } from '../../../constants/routes';
import { useRouter } from 'next/router';

// components
import AdministrationTable from '../../../components/adminTable';
import Sidebar from '../../../components/adminSidebar';
import SidebarButton from '../../../components/SidebarButton';
import Layout from '../../../components/layout';
import Loading from '../../../components/loading';
import NoData from '../../../components/noData';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from '../../../components/Animations';
import axios from 'axios';

const AdminEmails: React.FunctionComponent<IPage> = () => {
	let { t } = useTranslation();
	const router = useRouter();
	const colgroup = [5, 15, 55, 25];
	const thead = [
		'ID',
		`${t('adminEmails:thead2')}`,
		'Email',
		`${t('adminEmails:thead4')}`,
	];
	const wantedParams = ['id', 'created_at', 'email'];
	const [loaded, setLoaded] = useState(false);
	const [items, setItems] = useState([]);
	const buttons = [
		{
			name: `${t('adminEmails:thead4')}`,
			type: 'delete',
			table: 'email_collection',
			key: 'id',
			url: '',
		},
	];
	const [exportText, setExportText] = useState(`${t('adminEmails:button')}`);
	const [colorBtn, setColorBtn] = useState('');
	const [activeSideBar, setActiveSideBar] = useState(Boolean);
	const [user, setUser] = useState('');
	const [update, updateState] = React.useState(0);
	const forceUpdate = () => {
		updateState(update + 1);
	};
	const getExtract: any = () => {
		axios
			.get(`${ADDRESS}/email_collection`, {
				responseType: 'blob',
				headers: {
					Authorization: 'Bearer ' + localStorage.getItem('token').slice(1, -1),
				},
			})
			.then(res => {
				console.log(res);
				const url = window.URL.createObjectURL(new Blob([res.data]));
				const link = document.createElement('a');
				link.href = url;
				link.setAttribute('download', 'Email list.csv');
				document.body.appendChild(link);
				link.click();
			});
	};
	const getData = async () => {
		if (user === "prihlasen") {
			axios
				.get(`${ADDRESS}/emails_collection`)
				.then(res => {
					console.log(res.data);
					setItems(res.data);
				})
				.catch(err => {
					console.log(err);
				});
		}
	};
	getData();
	useEffect(() => {
		if (user === 'neprihlasen') {
			router.push(ROUTES.LOGIN);
		}
	}, [user, update]);

	useEffect(() => {
		if (items) {
			setLoaded(true);
		}
		if (
			!window.localStorage.getItem('logged') ||
			!window.localStorage.getItem('token')
		) {
			setUser('neprihlasen');
		} else {
			setUser('prihlasen');
		}
	}, [user]);

	if (user == 'neprihlasen') {
		return <div />;
	}
	return (
		<Layout
			title={t('SEO:adminEmails.title')}
			metaDescription={t('SEO:adminEmails.description')}
			robots={false}
			pageType={'website'}
		>
			<motion.div
				className={'adminContainer'}
				variants={pageAnimation}
				initial="hidden"
				animate="enter"
				exit="exit"
				transition={{ type: 'linear' }}
			>
				<div className={'addedControlls'}>
					<SidebarButton
						setActiveSideBar={setActiveSideBar}
						activeSideBar={activeSideBar}
					/>
					<div>
						<button
							id={'adminHelperBtn'}
							className={'emailButton adminHelperBtn ' + colorBtn}
							onClick={() => getExtract()}
						>
							{exportText}
						</button>
					</div>
				</div>
				<div className="flex-menu flex-col">
					<div className="w-full text-right text-white pageTitle py-3 pr-9 mb-5 flex gap-x-5 items-center justify-end">
						<span>{t('adminEmails:title')}</span>
					</div>
					<Sidebar activeSideBar={activeSideBar} />
				</div>
				<div className={'tableWrapper'}>
					{loaded ? (
						items.length > 0 ? (
							<AdministrationTable
								colgroup={colgroup}
								thead={thead}
								tbody={items}
								wantedParams={wantedParams}
								buttons={buttons}
								type={'addedRow'}
								additionalContent={null}
								additionalContentTXT={null}
								//@ts-ignore
								update={forceUpdate}
							/>
						) : (
							<NoData emailsErr={true} />
						)
					) : (
						<Loading />
					)}
				</div>
			</motion.div>
		</Layout>
	);
};

export default AdminEmails;