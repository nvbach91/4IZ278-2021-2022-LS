// react hooks
import React, { useState, useEffect } from 'react';
import useTranslation from 'next-translate/useTranslation';
import * as ROUTES from '../../../constants/routes';

// interfaces, routes
import IPage from '../../../interfaces/page';
import { ADDRESS } from '../../../constants/routes';

// components
import AdministrationTable from '../../../components/adminTable';
import Sidebar from '../../../components/adminSidebar';
import SidebarButton from '../../../components/SidebarButton';
import Layout from '../../../components/layout';
import Loading from '../../../components/loading';
import NoData from '../../../components/noData';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from '../../../components/Animations';
import { useRouter } from 'next/router';

import axios from 'axios';
import Router from 'next/router';

const Users: React.FunctionComponent<IPage> = () => {
	let { t } = useTranslation();
	const colgroup = [5, 10, 15, 15, 20, 20, 15];
	const [loaded, setLoaded] = useState(false);
	const router = useRouter();
	const thead = [
		'ID',
		'Role',
		`${t('adminUsers:thead3')}`,
		`${t('adminUsers:thead4')}`,
		`${t('adminUsers:thead5')}`,
		'Email',
		`${t('adminUsers:thead4')}`,
	];
	const wantedParams = [
		'user_id ',
		'role',
		'first_name',
		'last_name',
		'phone',
		'email',
	];
	const [items, setItems] = useState([]);
	const [user, setUser] = useState('');
	const buttons = [
		{
			name: `${t('adminUsers:thead7')}`,
			type: 'delete',
			table: 'user',
			key: 'id',
			url: '',
		},
	];
	const [activeSideBar, setActiveSideBar] = useState(Boolean);
	const [update, updateState] = React.useState(0);
	const forceUpdate = () => {
		updateState(update + 1);
	};

	// @ts-ignore
	useEffect(async () => {
		if (user === "prihlasen") {
			axios
				.get(`${ADDRESS}/admin/user`, {
					headers: {
						Authorization: 'Bearer ' + localStorage.getItem('token'),
					},
				})
				.then(res => {
					setItems(res.data.data);
				});
		}
	}, [user, update]);

	useEffect(() => {
		if (user === 'neprihlasen') {
			router.push(ROUTES.LOGIN);
		}
	}, [user]);

	useEffect(() => {
		if (items) {
			setLoaded(true);
		}
		if (
			!window.localStorage.getItem('logged') ||
			!window.localStorage.getItem('token')
		) {
			setUser('neprihlasen');
		} else {
			setUser('prihlasen');
		}
	}, [user]);

	
	if (user == 'neprihlasen') {
		return <div />;
	}

	return (
		<Layout
			title={t('SEO:adminUsers.title')}
			metaDescription={t('SEO:adminUsers.description')}
			robots={false}
			pageType={'website'}
		>
			<motion.div
				className={'adminContainer'}
				variants={pageAnimation}
				exit="exit"
				initial="hidden"
				animate="show"
			>
				<div className={'addedControlls'}>
					<SidebarButton
						setActiveSideBar={setActiveSideBar}
						activeSideBar={activeSideBar}
					/>
				</div>
				<div className="flex-menu flex-col">
					<div className="w-full text-right text-white pageTitle  pr-9 mb-5 flex gap-x-5 items-center justify-end py-3">
						<span>{t('adminUsers:title')}</span>
					</div>
					<Sidebar activeSideBar={activeSideBar} />
				</div>
				<div className={'tableWrapper'}>
					{loaded ? (
						items.length > 0 ? (
							<AdministrationTable
								colgroup={colgroup}
								thead={thead}
								tbody={items}
								wantedParams={wantedParams}
								buttons={buttons}
								type={'addedRow'}
								additionalContent={null}
								additionalContentTXT={null}
								//@ts-ignore
								update={forceUpdate}
							/>
						) : (
							<NoData ordersErr={true} />
						)
					) : (
						<Loading />
					)}
				</div>
			</motion.div>
		</Layout>
	);
};

export default Users;