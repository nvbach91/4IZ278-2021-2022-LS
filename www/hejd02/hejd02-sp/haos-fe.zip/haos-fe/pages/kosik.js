import React, { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/router';
import { useMainContext } from '../context/mainContext.js';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from '../components/Animations';
import gsap from 'gsap';

// components
import Layout from '../components/layout';
import CartFirst from '../components/cartFirst.js';
import CartSecond from '../components/cartSecond.js';
import CartThird from '../components/cartThird.js';
import CartFourth from '../components/cartFourth.js';
import CartErr from '../components/cartErr.js';
import LoginMessage from '../components/loginMessage';

import useTranslation from 'next-translate/useTranslation';

export default function Cart() {
	let { t } = useTranslation();
	// data from context
	const { kosikError } = useMainContext();
	const { setKosikError } = useMainContext();
	const { step } = useMainContext();
	const { setStep } = useMainContext();
	const { products } = useMainContext();
	const { items } = useMainContext();
	const { setItems } = useMainContext();
	const { total } = useMainContext();
	const { setTotal } = useMainContext();
	const { cartLoading } = useMainContext();
	const { setCartLoading } = useMainContext();
	const router = useRouter();
	const [loggedErrState, setLoggedErrState] = useState([false, ""]);

	if (typeof window !== 'undefined' && sessionStorage.getItem('step') === '4') {
		setTimeout(() => {
			sessionStorage.removeItem('personal_data');
			sessionStorage.removeItem('products');
			setTotal(0);
			setItems(0);
			setStep('');
		}, 1500);
	}

	useEffect(() => {
		if (
			(step === 'thirdToFourth' ||
				(step === '' && sessionStorage.getItem('step') === '4')) &&
			localStorage.getItem('userData') &&
			JSON.parse(localStorage.getItem('userData')).id
		) {
			const handleRouteChange = () => {
				sessionStorage.removeItem('step');
			};
			router.events.on('routeChangeStart', handleRouteChange);

			return () => {
				router.events.off('routeChangeStart', handleRouteChange);
			};
		}
	}, [step]);

	useEffect(() => {
		if (
			sessionStorage.getItem('step') === '4' &&
			!sessionStorage.getItem('products')
		) {
			sessionStorage.removeItem('step');
		}
	}, []);

	// animace
	const firstBox = useRef();
	const secondBox = useRef();
	const thirdBox = useRef();
	const fourthBox = useRef();
	const span1 = useRef();
	const span2 = useRef();
	const span3 = useRef();
	const span4 = useRef();
	let tl = gsap.timeline();

	const blackSpans = () => {
		const array = [span1.current, span2.current, span3.current, span4.current];
		array.forEach(element => {
			gsap.set(element, { backgroundColor: 'black' });
		});
	};

	const animFunctionOnClick = (first, second, direction, span) => {
		if (direction === '+') {
			tl.to(first, { x: '-100vw', ease: 'linear', duration: 0.35 });
			tl.to(first, { display: 'none' });
			tl.to(second, { display: 'block', onComplete: blackSpans() });
			tl.fromTo(
				second,
				{ x: '100vw', ease: 'linear', duration: 0.35 },
				{ x: 0, ease: 'linear', duration: 0.35 },
				'-=0.5',
			);
			tl.to(span, { backgroundColor: '#4B5563' }, '<');
		} else {
			tl.fromTo(
				second,
				{ x: 0, ease: 'linear', duration: 0.35 },
				{ x: '100vw', ease: 'linear', duration: 0.35 },
			);
			tl.to(second, { display: 'none' });
			tl.to(first, { display: 'block', onComplete: blackSpans() });
			tl.to(first, { x: 0, ease: 'linear', duration: 0.35 }, '-=0.5');
			tl.to(span, { backgroundColor: '#4B5563' }, '<');
		}
	};

	const animFunctionOnLoad = (box, span) => {
		blackSpans();
		tl.to(box, { display: 'block', duration: .35 });
		tl.to(span, { backgroundColor: '#4B5563', duration: .35 }, '<');
	};

	useEffect(() => {
		if (step && firstBox.current && span1.current) {
			setCartLoading(true);
		} else {
			setCartLoading(false);
		}
		if (
			(sessionStorage.getItem('step') === '1' && step === '') ||
			!sessionStorage.getItem('step') ||
			(sessionStorage.getItem('step') && sessionStorage.getItem('step') === '')
		) {
			animFunctionOnLoad(firstBox.current, span1.current);
		}
		if (sessionStorage.getItem('step') === '2' && step === '') {
			animFunctionOnLoad(secondBox.current, span2.current);
		}
		if (sessionStorage.getItem('step') === '3' && step === '') {
			animFunctionOnLoad(thirdBox.current, span3.current);
		}
		switch (step) {
			case 'firstToSecond':
				animFunctionOnClick(
					firstBox.current,
					secondBox.current,
					'+',
					span2.current,
				);
				break;
			case 'secondToThird':
				animFunctionOnClick(
					secondBox.current,
					thirdBox.current,
					'+',
					span3.current,
				);
				break;
			case 'thirdToFourth':
					animFunctionOnClick(
						thirdBox.current,
						fourthBox.current,
						'+',
						span4.current,
					);
					setLoggedErrState(false);
					setTimeout(() => {
						setItems(0);
					}, 1900);
				break;
			case 'secondToFirst':
				animFunctionOnClick(
					firstBox.current,
					secondBox.current,
					'-',
					span1.current,
				);
				break;
			case 'thirdToSecond':
				animFunctionOnClick(
					secondBox.current,
					thirdBox.current,
					'-',
					span2.current,
				);
				break;
			default:
				break;
		}
	}, [step, firstBox.current, span1.current]);

	return (
		<Layout
			title={t('SEO:cart.title')}
			metaDescription={t('SEO:cart.description')}
			robots={true}
			pageType={'website'}
		>
			<motion.div
				variants={pageAnimation}
				initial="hidden"
				animate="enter"
				exit="exit"
				transition={{ type: 'linear' }}
				className="mainWrapper z-1 cart"
			>
				<div className="mainContainer">
					<div className="cart__container mx-auto">
						{/* progress bar */}
						<div
							className={
								typeof window !== 'undefined' &&
								(sessionStorage.getItem('step') ||
									sessionStorage.getItem('step') === '')
									? 'cart__progressBar'
									: 'hidden'
							}
						>
							<div className="p-0 relative text-center w-full">
								<div className="flex mt-2 text-center p-0 justify-between items-center lg:w-2/6 md:w-3/6 w-9/12 mx-auto relative width">
									<div className="flex justify-center items-center flex-col p-0">
										<span
											ref={span1}
											className="bg-black flex justify-center items-center w-12 h-12 text-white font-bold mb-5 z-10"
										>
											1
										</span>
										<h3 className="absolute -bottom-5">{t('cart:number1')}</h3>
									</div>
									<div className="flex justify-center items-center flex-col p-0">
										<span
											ref={span2}
											className="bg-black flex justify-center items-center w-12 h-12 text-white font-bold mb-5 z-10"
										>
											2
										</span>
										<h3 className="absolute -bottom-5">{t('cart:number2')}</h3>
									</div>
									<div className="flex justify-center items-center flex-col p-0">
										<span
											ref={span3}
											className="bg-black flex justify-center items-center w-12 h-12 text-white font-bold mb-5 z-10"
										>
											3
										</span>
										<h3 className="absolute -bottom-5">{t('cart:number3')}</h3>
									</div>
									<div className="flex justify-center items-center flex-col p-0">
										<span
											ref={span4}
											className="bg-black flex justify-center items-center w-12 h-12 text-white font-bold mb-5 z-10"
										>
											4
										</span>
										<h3 className="absolute -bottom-5">{t('cart:number4')}</h3>
									</div>
								</div>
								<div className="absolute top-6 right-0 left-0 border-t-4 lg:w-2/6 md:w-3/6 w-9/12 mx-auto border-black width" />
							</div>
						</div>
						<CartFirst
							products={products}
							kosikError={kosikError}
							setKosikError={setKosikError}
							items={items}
							setItems={setItems}
							total={total}
							setTotal={setTotal}
							step={step}
							setStep={setStep}
							firstBox={firstBox}
						/>
						<CartSecond step={step} setStep={setStep} secondBox={secondBox} />
						<CartThird
							products={products}
							total={total}
							setTotal={setTotal}
							step={step}
							setStep={setStep}
							thirdBox={thirdBox}
							setLoggedErrState={setLoggedErrState}
						/>
						<CartFourth
							fourthBox={fourthBox}
							total={total}
							setTotal={setTotal}
							setItems={setItems}
						/>
						{loggedErrState[0] && <CartErr err={loggedErrState[1]} />}
						{typeof window !== 'undefined' &&
							sessionStorage.getItem('loggedAnim') && <LoginMessage />}
					</div>
				</div>
			</motion.div>
		</Layout>
	);
}
