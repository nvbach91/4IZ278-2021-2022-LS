import useTranslation from 'next-translate/useTranslation';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from '../components/Animations';

// link and routes
import Link from 'next/link';
import * as ROUTES from '../constants/routes';

// component
import Layout from '../components/layout';

const NotFound = () => {
	let { t } = useTranslation();
	return (
		<Layout
			title={t('SEO:404.title')}
			metaDescription={t('SEO:404.description')}
			robots={true}
			pageType={'website'}
		>
			<motion.div
				variants={pageAnimation}
				initial="hidden"
				animate="enter"
				exit="exit"
				transition={{ type: 'linear' }}
				className="notFoundContainer xl:pt-48 pt-28"
			>
				<div className="notFound xl:pb-24 lg:pb-12 pt-6 pb-12 xl:px-24 lg:px-16 md:px-12 px-4 mx-auto">
					<div className="notFound-wrapper sm:p-8 px-4 py-6 mx-auto flex justify-center items-center">
						<div className="notFound-wrapper-error md:p-5 p-3">404</div>
						<div className="md:p-5 p-3 flex flex-col gap-1">
							<div className="notFound-wrapper-text">
								<h3>{t('404:title')}</h3>
							</div>
							<div className="notFound-wrapper-text">{t('404:subtitle')}</div>
							<Link href={ROUTES.UVOD}>
								<a>
									<button className="flex items-center md:gap-3 gap-1.5">
										<span>&#8598;</span>
										<span>{t('404:button')}</span>
									</button>
								</a>
							</Link>
						</div>
					</div>
				</div>
			</motion.div>
		</Layout>
	);
};

export default NotFound;