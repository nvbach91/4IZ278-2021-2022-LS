// react hooks
import React, { useEffect } from 'react';

// routes, interfaces
import IPage from '../interfaces/page';
import * as ROUTES from '../constants/routes';
import Link from 'next/link';
import { ADDRESS } from '../constants/routes';
import useTranslation from 'next-translate/useTranslation';

//@ts-ignore
import icon from '../public/images/logOut-icon.png';
import axios from 'axios';
import Layout from '../components/layout';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from '../components/Animations';
// import { useUserData } from '../../context/main-data';
// import { timeout } from 'q';

// context
import { useMainContext } from '../context/mainContext.js';

const AdminLogOut: React.FunctionComponent<IPage> = () => {
	let { t } = useTranslation();
	const { setLogged } = useMainContext();
	// const { userData } = useUserData();
	// const { setUserData } = useUserData();
	// const { setUserTypeRedirect } = useUserData();
	// const { setLogged } = useUserData();

	// useEffect(() => {
	// 	let unmounted = false;
	// 	if (!unmounted) {
	// 		axios
	// 			.post(ADDRESS + '/user-signout', null, { withCredentials: true })
	// 			.then(response => {
	// 				sessionStorage.removeItem('user');
	// 				setUserData(false);
	// 				setUserTypeRedirect('');
	// 				setLogged(false);
	// 			})
	// 			.catch(err => {
	// 				console.log(err.response);
	// 			});
	// 	}
	// 	return () => {
	// 		unmounted = true;
	// 	};
	// }, []);

	useEffect(() => {
		if (typeof window !== 'undefined' && localStorage.getItem("logged")) {
			localStorage.removeItem("logged");
		}
		if (typeof window !== 'undefined' && localStorage.getItem('token')) {
			localStorage.removeItem('token');
		}
		if (typeof window !== 'undefined' && localStorage.getItem('userData')) {
			localStorage.removeItem('userData');
		}
		setLogged('');
	}, [])

	return (
		<Layout
			title={t('SEO:logOut.title')}
			metaDescription={t('SEO:logOut.description')}
			robots={false}
			pageType={'website'}
		>
			<motion.div
				className={
					'mainContainer md:pt-64 pt-36 xl:pb-44 lg:pb-12 pb-12 xl:px-24 lg:px-16 md:px-12 px-4 logoutContainer'
				}
				variants={pageAnimation}
				exit="exit"
				initial="hidden"
				animate="show"
			>
				{/* <UserSidebar activeSideBar={activeSideBar} /> */}
				<div className="logOut__cotainer md:mx-8 flex justify-center items-center flex-col mx-auto md:px-12 px-6 py-12">
					<img src={icon.src} alt="ikona" className="w-20" />
					<h3 className="my-7 text-center w-full">{t('logOut:text')}</h3>
					<Link href="/">
						<a>
							<button className="rounded-xl text-white px-6 py-3">
								{t('logOut:button')}
							</button>
						</a>
					</Link>
				</div>
			</motion.div>
		</Layout>
	);
};

export default AdminLogOut;