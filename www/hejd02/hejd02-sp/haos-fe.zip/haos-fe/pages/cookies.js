import React from 'react';
import useTranslation from 'next-translate/useTranslation';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from '../components/Animations';

// components
import Layout from '../components/layout';

export default function Cookies() {
	let { t } = useTranslation();
	return (
		<Layout
			title={t('SEO:cookies.title')}
			metaDescription={t('SEO:cookies.description')}
			robots={true}
			pageType={'website'}
		>
			<motion.div
				variants={pageAnimation}
				initial="hidden"
				animate="enter"
				exit="exit"
				transition={{ type: 'linear' }}
				className="mainWrapper z-1 cookies"
			>
				<div className="mainContainer">
					<div className="cookies-wrapper">
						<div className="first-part">
							<h1 className="font-semibold mb-7">{t('cookies:heading1')}</h1>
							<p className="mt-5">{t('cookies:text1')}</p>
							<div className="text mt-8">
								<h3 className="font-semibold mb-5">{t('cookies:heading2')}</h3>
								<p className="block mt-3">{t('cookies:text2_a')}</p>
								<p>{t('cookies:text2_b')}</p>
								<p>{t('cookies:text2_c')}</p>
							</div>
							<div className="text mt-8">
								<h1 className="font-semibold mb-3">{t('cookies:heading3')}</h1>
								<p className="pt-5">{t('cookies:text3')}</p>
								<ul className="my-6">
									<li>
										{t('cookies:text4')}{' '}
										<span className="blue">
											<a
												href="https://policies.google.com/?hl=cs"
												target="_blank"
												rel="noreferrer"
											>
												{t('cookies:button')}
											</a>
										</span>
									</li>
									<li className="mt-3">
										{t('cookies:text5')}
										<span className="blue">
											<a
												href="https://www.facebook.com/full_data_use_policy"
												target="_blank"
												rel="noreferrer"
											>
												{t('cookies:button')}
											</a>
										</span>
									</li>
									<li className="mt-3">
										{t('cookies:text6')}
										<span className="blue">
											{' '}
											<a
												href="https://www.linkedin.com/legal/cookie-policy?_l=cs_CZ"
												target="_blank"
												rel="noreferrer"
											>
												{t('cookies:button')}
											</a>
										</span>{' '}
										{t('cookies:and')}{' '}
										<span className="blue">
											<a
												href="https://www.linkedin.com/legal/privacy-policy"
												target="_blank"
												rel="noreferrer"
											>
												{t('cookies:button')}
											</a>
										</span>
										.
									</li>
									<li className="mt-3">
										{t('cookies:text7')}{' '}
										<span className="blue">
											<a
												href="https://twitter.com/en/privacy"
												target="_blank"
												rel="noreferrer"
											>
												{t('cookies:button')}
											</a>
										</span>
										.
									</li>
								</ul>
								<p>{t('cookies:text8')}</p>
							</div>

							<div className="text mt-8">
								<h1 className="font-semibold mb-3">{t('cookies:heading4')}</h1>
								<p className="mt-5">{t('cookies:text9')}</p>
							</div>
						</div>
						<div className="tableDiv">
							<table className="table mt-10">
								<tbody>
									<tr>
										<th>{t('cookies:typ')}</th>
										<th>{t('cookies:cookieName')}</th>
										<th>{t('cookies:purpose')}</th>
										<th>{t('cookies:retentionPeriod')}</th>
										<th>{t('cookies:whoGetsTheInformation')}</th>
									</tr>
									<tr>
										<td>{t('cookies:preferentialType')}</td>
										<td>lang</td>
										<td>
											{t('cookies:cookie1:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.linkedin.com/legal/cookie-policy?_l=cs_CZ"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie1:retentionPeriod')}</td>
										<td>linkedin.com</td>
									</tr>
									<tr>
										<td>{t('cookies:staticType')}</td>
										<td>_ga</td>
										<td>{t('cookies:cookie2:purpose')} </td>
										<td>{t('cookies:cookie2:retentionPeriod')}</td>
										<td>bodyperformance.cz</td>
									</tr>
									<tr>
										<td>{t('cookies:staticType')}</td>
										<td>_gat</td>
										<td>
											{t('cookies:cookie3:purpose')}{' '}
											<span className="blue">
												<a
													href="https://policies.google.com/?hl=cs"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie3:retentionPeriod')}</td>
										<td>bodyperformance.cz</td>
									</tr>
									<tr>
										<td>{t('cookies:staticType')}</td>
										<td>_gid</td>
										<td>
											{t('cookies:cookie4:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.linkedin.com/legal/cookie-policy?_l=cs_CZ"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie4:retentionPeriod')}</td>
										<td>bodyperformance.cz</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>_fbp</td>
										<td>
											{t('cookies:cookie5:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.facebook.com/full_data_use_policy"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie5:retentionPeriod')}</td>
										<td>bodyperformance.cz</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>bcookie</td>
										<td>
											{t('cookies:cookie6:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.linkedin.com/legal/cookie-policy?_l=cs_CZ"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie6:retentionPeriod')}</td>
										<td>linkedin.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>BizoID</td>
										<td>{t('cookies:cookie7:purpose')}</td>
										<td>{t('cookies:cookie7:retentionPeriod')}</td>
										<td>ads.linkedin.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>bscookie</td>
										<td>
											{t('cookies:cookie8:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.linkedin.com/legal/cookie-policy?_l=cs_CZ"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie8:retentionPeriod')}</td>
										<td>linkedin.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>c</td>
										<td>
											{t('cookies:cookie9:purpose')}{' '}
											<span className="blue">
												<a
													href="https://bodyperformance.cz/gdpr/"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie9:retentionPeriod')}</td>
										<td>leady.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>fr</td>
										<td>
											{t('cookies:cookie10:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.facebook.com/full_data_use_policy"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie10:retentionPeriod')}</td>
										<td>facebook.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>lang</td>
										<td>{t('cookies:cookie11:purpose')}</td>
										<td>{t('cookies:cookie11:retentionPeriod')}</td>
										<td>ads.linkedin.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>lidc</td>
										<td>
											{t('cookies:cookie12:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.linkedin.com/legal/cookie-policy?_l=cs_CZ"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie12:retentionPeriod')}</td>
										<td>linkedin.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>personalization_id</td>
										<td>
											{t('cookies:cookie13:purpose')}{' '}
											<span className="blue">
												<a
													href="https://twitter.com/en/privacy"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie13:retentionPeriod')}</td>
										<td>twitter.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>UserMatchHistory</td>
										<td>{t('cookies:cookie14:purpose')}</td>
										<td>{t('cookies:cookie14:retentionPeriod')}</td>
										<td>linkedin.com</td>
									</tr>
									<tr>
										<td>{t('cookies:unclassifiedType')}</td>
										<td>leady_session_id</td>
										<td>{t('cookies:cookie15:purpose')}</td>
										<td>{t('cookies:cookie15:retentionPeriod')}</td>
										<td>bodyperformance.cz</td>
									</tr>
								</tbody>
							</table>
							<br />
							<table className="table mt-7">
								<tbody>
									<tr>
										<th>{t('cookies:type')}</th>
										<th>{t('cookies:cookieName')}</th>
										<th>{t('cookies:purpose')}</th>
										<th>{t('cookies:retentionPeriod')}</th>
										<th>{t('cookies:whoGetsTheInformation')}</th>
									</tr>

									<tr>
										<td>{t('cookies:necessaryType')}</td>
										<td>__cfduid </td>
										<td>
											{t('cookies:cookie16:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.cloudflare.com/gdpr/introduction/"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie16:retentionPeriod')}</td>
										<td>artbees.net</td>
									</tr>
									<tr>
										<td>{t('cookies:preferentialType')}</td>
										<td>lang</td>
										<td>
											{t('cookies:cookie17:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.linkedin.com/legal/cookie-policy?_l=cs_CZ"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie17:retentionPeriod')}</td>
										<td>linkedin.com</td>
									</tr>
									<tr>
										<td>{t('cookies:staticType')}</td>
										<td>_ga</td>
										<td>{t('cookies:cookie18:purpose')}</td>
										<td>{t('cookies:cookie18:retentionPeriod')}</td>
										<td>bodyperformance.cz</td>
									</tr>
									<tr>
										<td>{t('cookies:staticType')}</td>
										<td>_gat</td>
										<td>
											{t('cookies:cookie19:purpose')}{' '}
											<span className="blue">
												<a
													href="https://policies.google.com/?hl=cs"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie19:retentionPeriod')}</td>
										<td>bodyperformance.cz</td>
									</tr>
									<tr>
										<td>{t('cookies:preferentialType')}</td>
										<td>_gid</td>
										<td>{t('cookies:cookie20:purpose')}</td>
										<td>{t('cookies:cookie20:retentionPeriod')}</td>
										<td>bodyperformance.cz</td>
									</tr>

									<tr>
										<td>{t('cookies:staticType')}</td>
										<td>p.gif </td>
										<td>{t('cookies:cookie21:purpose')}</td>
										<td>{t('cookies:cookie21:retentionPeriod')}</td>
										<td>typekit.net</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>_fbp </td>
										<td>
											{t('cookies:cookie22:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.facebook.com/full_data_use_policy"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie22:retentionPeriod')}</td>
										<td>bodyperformance.cz</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>ads/ga-audiences </td>
										<td>
											{t('cookies:cookie23:purpose')}{' '}
											<span className="blue">
												<a
													href="https://policies.google.com/?hl=cs"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie23:retentionPeriod')}</td>
										<td>google.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>bcookie </td>
										<td>
											{t('cookies:cookie24:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.linkedin.com/legal/cookie-policy?_l=cs_CZ"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie24:retentionPeriod')}</td>
										<td>linkedin.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>bscookie </td>
										<td>
											{t('cookies:cookie25:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.linkedin.com/legal/cookie-policy?_l=cs_CZ"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie25:retentionPeriod')}</td>
										<td>linkedin.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>fr</td>
										<td>
											{t('cookies:cookie26:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.facebook.com/full_data_use_policy"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie26:retentionPeriod')}</td>
										<td>facebook.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>GPS </td>
										<td>{t('cookies:cookie27:purpose')}</td>
										<td>{t('cookies:cookie27:retentionPeriod')}</td>
										<td>youtube.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>i/adsct </td>
										<td>
											{t('cookies:cookie28:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.linkedin.com/legal/cookie-policy?_l=cs_CZ"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie28:retentionPeriod')}</td>
										<td>t.co</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>IDE </td>
										<td>
											{t('cookies:cookie29:purpose')}{' '}
											<span className="blue">
												<a
													href="https://policies.google.com/?hl=cs"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie29:retentionPeriod')}</td>
										<td>doubleclick.net </td>
									</tr>

									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>lang</td>
										<td>{t('cookies:cookie30:purpose')}</td>
										<td>{t('cookies:cookie30:retentionPeriod')}</td>
										<td>ads.linkedin.com</td>
									</tr>

									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>lidc</td>
										<td>
											{t('cookies:cookie31:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.linkedin.com/legal/cookie-policy?_l=cs_CZ"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie31:retentionPeriod')}</td>
										<td>linkedin.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>personalization_id </td>
										<td>
											{t('cookies:cookie32:purpose')}{' '}
											<span className="blue">
												<a
													href="https://twitter.com/en/privacy"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie32:retentionPeriod')}</td>
										<td>twitter.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>PREF </td>
										<td>
											{t('cookies:cookie33:purpose')}{' '}
											<span className="blue">
												<a
													href="https://policies.google.com/?hl=cs"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie33:retentionPeriod')}</td>
										<td>youtube.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>test_cookie</td>
										<td>{t('cookies:cookie34:purpose')}</td>
										<td>{t('cookies:cookie34:retentionPeriod')}</td>
										<td>doubleclick.net</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>tr</td>
										<td>
											{t('cookies:cookie35:purpose')}{' '}
											<span className="blue">
												<a
													href="https://www.facebook.com/full_data_use_policy"
													target="_blank"
													rel="noreferrer"
												>
													{t('cookies:button')}
												</a>
											</span>
										</td>
										<td>{t('cookies:cookie35:retentionPeriod')}</td>
										<td>facebook.com</td>
									</tr>

									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>UserMatchHistory</td>
										<td>{t('cookies:cookie36:purpose')}</td>
										<td>{t('cookies:cookie36:retentionPeriod')}</td>
										<td>linkedin.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>VISITOR_INFO1_LIVE</td>
										<td>{t('cookies:cookie37:purpose')}</td>
										<td>{t('cookies:cookie37:retentionPeriod')}</td>
										<td>youtube.com</td>
									</tr>
									<tr>
										<td>{t('cookies:marketingType')}</td>
										<td>YSC</td>
										<td>{t('cookies:cookie38:purpose')}</td>
										<td>{t('cookies:cookie38:retentionPeriod')}</td>
										<td>youtube.com</td>
									</tr>
									<tr>
										<td>{t('cookies:unclassifiedType')}</td>
										<td>leady_session_id</td>
										<td>{t('cookies:cookie39:purpose')}</td>
										<td>{t('cookies:cookie39:retentionPeriod')}</td>
										<td>bodyperformance.cz</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</motion.div>
		</Layout>
	);
}