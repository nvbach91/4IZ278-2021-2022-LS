import type { ReactElement, ReactNode } from 'react';
import type { NextPage } from 'next';
import type { AppProps } from 'next/app';
import React, {useEffect} from "react";
import Router from 'next/router';

// aos
import AOS from 'aos';
import 'aos/dist/aos.css';

// styles
import '../styles/globals.css';
import '../styles/App.scss';

import { MainProvider } from '../context/mainContext';

// components
import Loading from "../components/loading";

// light box
import SimpleReactLightbox from 'simple-react-lightbox';

type NextPageWithLayout = NextPage & {
	getLayout?: (page: ReactElement) => ReactNode;
};

type AppPropsWithLayout = AppProps & {
	Component: NextPageWithLayout;
};

export default function MyApp({ Component, pageProps }: AppPropsWithLayout) {
	const [loading, setLoading] = React.useState(false);
	React.useEffect(() => {
		const start = () => {
			setLoading(true);
		};
		const end = () => {
			setLoading(false);
		};
		Router.events.on('routeChangeStart', start);
		Router.events.on('routeChangeComplete', end);
		Router.events.on('routeChangeError', end);
		return () => {
			Router.events.off('routeChangeStart', start);
			Router.events.off('routeChangeComplete', end);
			Router.events.off('routeChangeError', end);
		};
	}, []);
	const getLayout = Component.getLayout ?? ((page: ReactNode) => page);
	
	useEffect(() => {
		AOS.init({
			once: true,
		});
	}, []);
	return (
		<MainProvider>
			{loading ? (
				<Loading />
			) : (
				getLayout(
					<SimpleReactLightbox>

						<Component {...pageProps} />

					</SimpleReactLightbox>,
				)
			)}
		</MainProvider>
	);
}
