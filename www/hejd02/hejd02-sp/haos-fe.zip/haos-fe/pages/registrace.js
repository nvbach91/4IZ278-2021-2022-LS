// react hooks
import React, { useState, useRef } from 'react';
import { useForm } from 'react-hook-form';
import useTranslation from 'next-translate/useTranslation';
import { useRouter } from 'next/router';
import axios from 'axios';

// animations
import { motion } from 'framer-motion';
import { pageAnimation } from '../components/Animations';

// links and routes, login
import * as ROUTES from '../constants/routes';
import Link from 'next/link';
import Router from 'next/router';

// component
import Layout from '../components/layout';
import { ADDRESS } from '../constants/routes';

// context
import { useMainContext } from '../context/mainContext.js';

// import {
// 	ADDRESS,
// 	ADMIN,
// 	LOGGED_DATA,
// 	SET_LOGGED_DATA,
// 	USER_PROFILE,
// } from '../constants/routes';
// import { LoginChecker } from '../components/loginChecker';

const Registrace = props => {
	const [errorMsg, setErrorMsg] = useState('');
	const [succMsg, setSuccMsg] = useState('');
	const [dataForm, setDataForm] = useState([]);
	const [activated, setActivated] = useState(false);
	const formLoginRef = useRef();
	let { t } = useTranslation();
	const router = useRouter();
	const { setLogged } = useMainContext();

	// function useQuery() {
	// 	const { search } = useLocation();
	// 	return React.useMemo(() => new URLSearchParams(search), [search]);
	// }

	// const urlQuery = useQuery();
	// let activ = urlQuery.get('status');

	// useEffect(() => {
	// 	if (activ === 'activated') {
	// 		setActivated(true);
	// 	}
	// }, []);

	const {
		register,
		handleSubmit,
		reset,
		watch,
		formState: { errors },
	} = useForm();

	const password = useRef({});
	password.current = watch('password', '');

	const tryRegister = data => {
		onRegister(data);
	};

	const onRegister = async data => {
		let result = await fetch(`${ADDRESS}/user`, {
			method: 'POST',
			body: JSON.stringify(data),
			headers: {
				'Content-Type': 'application/json',
				Accept: 'application/json',
			},
		});

		let resultJson = await result.json();
		switch (await result.status) {
			case 401:
				setErrorMsg(resultJson.user);
				break;
			case 422:
				if (router.locale === 'cs') {
					setErrorMsg('Tento email je již zaregistrovaný');
				} else {
					setErrorMsg(resultJson.message);
				}
				break;
			case 201:
				setErrorMsg('');
				sessionStorage.setItem('loggedAnim', true); // na spusteni animace
				Router.push(ROUTES.LOGIN);
				break;
		}
	};

	// const userRole = token => {
	// 	axios
	// 		.post(`${ADDRESS}/user-auth`, {
	// 			headers: {
	// 				'Content-Type': 'application/json',
	// 				Authorization: 'Bearer ' + token,
	// 			},
	// 		})
	// 		.then(res => {
	// 			localStorage.setItem('userRole', res.data.data.role);
	// 			setLogged(res.data.data.role);
	// 		});
	// };

	// LoginChecker(true, props.status);

	return (
		<Layout
			title={t('SEO:register.title')}
			metaDescription={t('SEO:register.description')}
			robots={true}
			pageType={'website'}
		>
			<motion.div
				variants={pageAnimation}
				initial="hidden"
				animate="enter"
				exit="exit"
				transition={{ type: 'linear' }}
				className="bg-white h-auto px-2 flex justify-center items-center registrace pt-72 pb-80"
			>
				<form
					action=""
					className="bg-white px-5 text-center"
					onSubmit={handleSubmit(tryRegister)}
				>
					<div className="py-6">
						<h1 className="font-medium">{t('registration:title')}</h1>
						<p className="font-normal gray">{t('registration:subtitle')}</p>
					</div>

					<div className="mb-2">
						<input
							className="border-2 border-gray-200 py-3 px-4 appearance-none w-full rounded-lg leading-tight focus:outline-none"
							id="first_name"
							type="text"
							placeholder={t('registration:firstNamePlaceholder')}
							{...register('first_name', {
								required: `${t('registration:firstNameRequiredError')}`,
								maxLength: 40,
							})}
						/>
						{errors.first_name && errors.first_name.type === 'required' && (
							<p className="h-6 text-left mt-1 err">
								{errors.first_name.message}
							</p>
						)}
					</div>
					<div className="mb-2">
						<input
							className="border-2 border-gray-200 py-3 px-4 appearance-none w-full rounded-lg leading-tight focus:outline-none"
							id="last_name"
							type="text"
							placeholder={t('registration:lastNamePlaceholder')}
							{...register('last_name', {
								required: `${t('registration:lastNameRequiredError')}`,
								maxLength: 40,
							})}
						/>
						{errors.last_name && errors.last_name.type === 'required' && (
							<p className="h-6 text-left mt-1 err">
								{errors.last_name.message}
							</p>
						)}
					</div>
					<div className="mb-2">
						<input
							className="border-2 border-gray-200 py-3 px-4 appearance-none w-full rounded-lg leading-tight focus:outline-none"
							id="email"
							type="text"
							placeholder="Email"
							{...register('email', {
								required: `${t('registration:emailRequiredError')}`,
								pattern: /^\S+@\S+$/i,
							})}
						/>
						{errors.email && errors.email.type === 'required' && (
							<p className="h-6 text-left mt-1 err">{errors.email.message}</p>
						)}

						{errors.email && errors.email.type === 'pattern' && (
							<p className="h-6 text-left mt-1 err">
								{t('registration:emailPatternError')}
							</p>
						)}
					</div>
					<div className="mb-2">
						<input
							className="border-2 border-gray-200 py-3 px-4 appearance-none w-full rounded-lg  leading-tight focus:outline-none"
							id="heslo"
							type="password"
							placeholder={t('registration:passwordPlaceholder')}
							{...register('password', {
								required: `${t('registration:passwordRequiredError')}`,
								maxLength: 40,
								minLength: 5,
							})}
						/>
						{errors.password && errors.password.type === 'required' && (
							<p className="h-6 text-left mt-1 err">
								{errors.password.message}
							</p>
						)}

						{errors.password && errors.password.type === 'minLength' && (
							<p className="h-6 text-left mt-1 err">
								{t('registration:passwordLengthError')}
							</p>
						)}
					</div>
					<div className="w-full">
						<input
							className="border-2 border-gray-200 py-3 px-4 appearance-none w-full rounded-lg leading-tight focus:outline-none"
							id="passwordAgain"
							type="password"
							placeholder={t('registration:passwordAgainPlaceholder')}
							{...register('passwordAgain', {
								required: `${t('registration:passwordAgainRequiredError')}`,
								minLength: 5,
								validate: value =>
									value === password.current || 'Passwords must be identical!',
							})}
						/>
						{errors.passwordAgain &&
							(errors.passwordAgain.type === 'required' ||
								errors.passwordAgain.type === 'validate') && (
								<p className="h-6 text-left mt-1 err">
									{errors.passwordAgain.message}
								</p>
							)}
						{errors.passwordAgain &&
							errors.passwordAgain.type === 'minLength' && (
								<p className="h-6 text-left mt-1 err">
									{t('registration:passwordLengthError')}
								</p>
							)}
					</div>
					<div className="justify-end flex mt-3">
						<p className="transitions font-normal  gray">
							{t('registration:account')}{' '}
							<Link href={ROUTES.LOGIN}>
								<a className="zapomenute-heslo-button cursor-pointer">
									{' '}
									{t('registration:login')}
								</a>
							</Link>
						</p>
					</div>
					<div className="buttons flex mt-5 mb-3 justify-center items-center">
						<button
							type="submit"
							onClick={handleSubmit}
							className="ml-4 my-6 md:py-2.5 py-2 w-44 leading-7 text-white font-medium rounded-xl justify-center items-center flex RegistraceBtn"
						>
							{t('registration:registerBtn')}
						</button>
					</div>
					{errorMsg ? (
						<div className={'w-full mb-6'}>
							<label
								className={'h-6 text-left mt-1 err err-login'}
								style={{ margin: '0 auto 20px' }}
							>
								{errorMsg}
							</label>
						</div>
					) : null}
					{/*{activated ? (*/}
					{/*	<div className="buttons flex mt-5 mb-3 justify-center items-center">*/}
					{/*		<label*/}
					{/*			className={'alert succAlert'}*/}
					{/*			style={{ margin: '0 auto 20px' }}*/}
					{/*		>*/}
					{/*			Váš účet byl aktivován! Nyní se už můžete přihlásit.*/}
					{/*		</label>*/}
					{/*	</div>*/}
					{/*) : null} */}
				</form>
			</motion.div>
		</Layout>
	);
};

export default Registrace;