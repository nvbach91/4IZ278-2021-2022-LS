export const ADDRESS ='https://api.haos.store'

// export const ADDRESS ='http://127.0.0.1:8000'

export const ADDRESS_SEO = 'https://haos.store';

export const UVOD = '/';

export const COOKIES = '/cookies';
export const GDPR = '/gdpr';
export const CART = '/kosik';
export const LOGIN = '/prihlaseni';
export const TERMS_AND_CONDITIONS = '/obchodni-podminky';
export const ADMIN_MESSAGES = '/admin/zpravy';
export const ADMIN_EMAILS = '/admin/emaily';
export const ADMIN_ORDERS = '/admin/objednavky';
export const LOGOUT = '/odhlaseni';
export const ADMIN_PRODUCTS = '/admin/produkty';
export const ADMIN_USERS = '/admin/uzivatele';
export const ABOUT = '/o-nas';
export const CONTACT = '/kontakt';
export const REGISTER = '/registrace';
